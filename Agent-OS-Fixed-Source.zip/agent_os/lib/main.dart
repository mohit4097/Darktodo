import 'package:flutter/material.dart';
import 'core/app_state.dart';
import 'core/notification_service.dart';
import 'core/theme.dart';
import 'pages/root_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.instance.init();
  await AppState.instance.init();

  final prefs = AppState.instance.prefs;
  final shouldAskForNotifications = !(prefs.getBool('asked_notif') ?? false);
  if (shouldAskForNotifications) {
    await prefs.setBool('asked_notif', true);
  }

  runApp(const AgentApp());

  // Request Android 13+ notification permission only after the first frame,
  // so the app UI is visible before Android displays its permission dialog.
  if (shouldAskForNotifications) {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      NotificationService.instance.requestPermission();
    });
  }
}

class AgentApp extends StatelessWidget {
  const AgentApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'AGENT.OS',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const RootGate(),
      );
}
