import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'models.dart';

/// Android local notification scheduler.
/// All scheduled DateTimes are interpreted in India Standard Time (Asia/Kolkata).
/// The app is currently targeted at the user's India deployment.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static const int _slots = 64;
  static const AndroidNotificationChannel _channel = AndroidNotificationChannel(
    'agent_alerts',
    'Mission Alerts',
    description: 'Reminders and alerts from AGENT.OS',
    importance: Importance.max,
    playSound: true,
    enableVibration: true,
  );

  Future<void> init() async {
    tzdata.initializeTimeZones();
    // timezone's default location is UTC. Set the actual app timezone explicitly
    // so a reminder selected at (for example) 8:00 AM fires at 8:00 AM in India.
    tz.setLocalLocation(tz.getLocation('Asia/Kolkata'));

    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(
      const InitializationSettings(android: android),
      onDidReceiveNotificationResponse: _onNotificationResponse,
    );

    final androidPlugin = _android;
    await androidPlugin?.createNotificationChannel(_channel);
  }

  void _onNotificationResponse(NotificationResponse response) {
    // Reserved for notification-tap routing. No navigation is required currently.
  }

  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  Future<bool> requestPermission() async {
    try {
      final result = await _android?.requestNotificationsPermission();
      // On Android versions before 13, the runtime request returns null because
      // notifications do not use POST_NOTIFICATIONS. Check the app-level state.
      return result ?? await _android?.areNotificationsEnabled() ?? true;
    } catch (_) {
      return false;
    }
  }

  Future<bool> requestExactAlarms() async {
    try {
      final canSchedule = await _android?.canScheduleExactNotifications();
      if (canSchedule == true) return true;
      return await _android?.requestExactAlarmsPermission() ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<AndroidScheduleMode> _mode() async {
    try {
      final can = await _android?.canScheduleExactNotifications();
      if (can == true) return AndroidScheduleMode.exactAllowWhileIdle;
    } catch (_) {}
    // Inexact reminders are still scheduled if Android exact-alarm access is
    // denied; Android may deliver them later than the selected minute.
    return AndroidScheduleMode.inexactAllowWhileIdle;
  }

  NotificationDetails _details(String body) => NotificationDetails(
        android: AndroidNotificationDetails(
          _channel.id,
          _channel.name,
          channelDescription: _channel.description,
          importance: Importance.max,
          priority: Priority.high,
          playSound: true,
          enableVibration: true,
          styleInformation: BigTextStyleInformation(body),
        ),
      );

  Future<void> showNow(String title, String body) async {
    try {
      await _plugin.show(0, title, body, _details(body));
    } catch (_) {}
  }

  Future<void> scheduleSeries({
    required int base,
    required List<DateTime> times,
    required String title,
    required String body,
    bool clear = true,
  }) async {
    if (clear) await cancelSeries(base);
    final mode = await _mode();
    final now = DateTime.now();
    for (var i = 0; i < times.length && i < kMaxSeries; i++) {
      final localTime = times[i].isUtc ? times[i].toLocal() : times[i];
      if (!localTime.isAfter(now)) continue;
      try {
        await _plugin.zonedSchedule(
          base * _slots + i,
          title,
          body,
          tz.TZDateTime.from(localTime, tz.local),
          _details(body),
          androidScheduleMode: mode,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
          payload: 'agent_os:$base:$i',
        );
      } catch (_) {
        // Keep scheduling the remaining reminders if one individual alarm fails.
      }
    }
  }

  Future<void> cancelSeries(int base) async {
    try {
      final pending = await _plugin.pendingNotificationRequests();
      for (final p in pending) {
        if (p.id ~/ _slots == base) await _plugin.cancel(p.id);
      }
    } catch (_) {}
  }

  Future<void> cancelAll() async {
    try {
      await _plugin.cancelAll();
    } catch (_) {}
  }
}
