# AGENT.OS

Dark mission-control productivity app built with Flutter for Android.

## Notification fixes in this build

- Requests Android 13+ notification permission on first launch.
- Creates the `Mission Alerts` notification channel at startup.
- Uses the `Asia/Kolkata` timezone instead of accidentally scheduling local reminders as UTC.
- Uses exact alarms when Android grants exact-alarm access, and falls back to inexact alarms otherwise.
- Includes notification and boot receivers in the generated Android manifest.
- Adds Settings actions for notification permission, exact-alarm access, and a test notification.

**Important Android setup:** After installing, open AGENT.OS → Settings → Notifications. Tap **ALLOW**, **ENABLE** under Exact alarms, then **TEST**. On Xiaomi/Redmi phones, also allow notifications for AGENT.OS and set Battery saver to **No restrictions**. Some device firmware may still delay background alarms. Android may also clear alarms when the app is force-stopped; open the app again after force-stopping it.

## Features

- Password lock (optional)
- Missions with date/time and repeat reminders
- Scheduled alerts and notification history
- Mission history
- Dashboard charts
- Habits, focus timer, exams countdown, expenses, and GPA calculator
- Local on-device storage

## Build the APK on GitHub

1. Upload all files in this folder to the repository root (keep `.github/`).
2. Open GitHub **Actions** → **Build APK** → run the workflow, or push to `main`/`master`.
3. Download the `agent-os-apk` artifact and extract `app-release.apk`.

The workflow generates the Android project and applies the notification permissions/receivers and Java desugaring configuration. The repository intentionally does not include a generated `android/` folder.

## Known platform limits

- Exact delivery depends on the user granting Android exact-alarm access.
- Android/OEM battery management can delay alarms; disable battery optimization for AGENT.OS where available.
- Android does not deliver alarms while an app is force-stopped. Launch the app again to restore normal scheduling.
- The current timezone is explicitly set to `Asia/Kolkata` for this India-focused build.
