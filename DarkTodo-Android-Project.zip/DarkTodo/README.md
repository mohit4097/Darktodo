# DarkTodo — Android project (Phase 1 foundation)

Native Android application project using Java + XML, min SDK 26 (Android 8.0), Room local database, AlarmManager reminders, notification history, a dark navy/electric-blue/violet theme, and a navigation drawer.

## Important build status

This project was generated in an environment without the Android SDK or Gradle installed. It has **not** been compiled or device-tested here. Do not treat this ZIP as a verified installable APK. The included GitHub Actions workflow is intended to compile a debug APK in a GitHub-hosted Android build environment after the project is pushed to a repository.

## Included in this source snapshot

- Java + XML Android app structure
- Room entities and DAO for tasks, activity history, notes, habits, and focus sessions
- Local task creation, due date/time selection, completion, pause/resume, and deletion
- One-shot and interval reminders (30 min, 1, 2, 3, 6, 12, 24 hours)
- Notification channel and runtime notification permission request
- Reminder event history stored locally
- Alarm restoration receiver after device reboot / app update
- Dark themed main shell, bottom navigation, and navigation drawer
- Local notes and basic habit list
- Basic focus countdown and live task-count analytics
- EncryptedSharedPreferences-backed optional local app credential setting
- GitHub Actions workflow for building a debug APK

## Known gaps before a production release

This is a source foundation, not yet a complete production release. The app lock currently needs a full security review and proper lifecycle/biometric/auto-lock handling; backup/restore, full calendar editing, richer academic planner, focus-session persistence, full chart analytics, and accessibility/device testing are not complete. Exact-alarm permission behavior also needs testing across Android versions and OEM battery restrictions. Firebase is intentionally not configured in this local-only phase.

These gaps are stated explicitly rather than represented as finished features.

## Build APK with GitHub Actions (phone-friendly route)

1. Create a new GitHub repository.
2. Upload the contents of this folder to the repository root (not the enclosing `DarkTodo` folder).
3. Open the repository's **Actions** tab.
4. Run **Build DarkTodo APK** (or push to `main`).
5. Open the completed workflow run and download the `DarkTodo-debug-apk` artifact.
6. Extract the artifact ZIP on Android and install `app-debug.apk`. Android may ask you to allow installs from your file manager/browser.

## Package

- Application ID: `com.darktodo.app`
- Display name: `DarkTodo`
- Version: `1.0.0` (debug build)
