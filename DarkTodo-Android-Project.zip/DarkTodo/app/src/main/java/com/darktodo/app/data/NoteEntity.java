package com.darktodo.app.data;
import androidx.room.Entity; import androidx.room.PrimaryKey;
@Entity(tableName="notes")
public class NoteEntity { @PrimaryKey(autoGenerate=true) public long id; public String title; public String body; public long updatedAt; }
