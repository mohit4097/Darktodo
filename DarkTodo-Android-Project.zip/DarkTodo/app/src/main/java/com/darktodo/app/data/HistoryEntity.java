package com.darktodo.app.data;
import androidx.room.Entity; import androidx.room.PrimaryKey;
@Entity(tableName="history")
public class HistoryEntity { @PrimaryKey(autoGenerate=true) public long id; public long taskId; public String title; public String event; public long eventAt; }
