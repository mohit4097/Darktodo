package com.darktodo.app.reminder;
import android.app.*; import android.content.*; import android.os.Build; import androidx.core.app.NotificationCompat; import com.darktodo.app.MainActivity; import com.darktodo.app.data.*;
public class ReminderReceiver extends BroadcastReceiver {
 public static final String CHANNEL="darktodo_reminders";
 @Override public void onReceive(Context context,Intent intent){
  long id=intent.getLongExtra("taskId",0); String title=intent.getStringExtra("title"); long interval=intent.getLongExtra("interval",0); long until=intent.getLongExtra("repeatUntil",0);
  AppDatabase.databaseWriteExecutor.execute(()->{
   TaskEntity task=AppDatabase.get(context).dao().taskById(id);
   if(task==null||task.completed||task.paused)return;
   createChannel(context); Intent open=new Intent(context, MainActivity.class); PendingIntent content=PendingIntent.getActivity(context,(int)id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
   Notification n=new NotificationCompat.Builder(context,CHANNEL).setSmallIcon(android.R.drawable.ic_popup_reminder).setContentTitle("DARKTODO · Reminder").setContentText(title==null?"You have a task to do":title).setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(content).build();
   NotificationManager nm=(NotificationManager)context.getSystemService(Context.NOTIFICATION_SERVICE); if(nm!=null)nm.notify((int)id,n);
   HistoryEntity h=new HistoryEntity(); h.taskId=id; h.title=title; h.event="REMINDER_SENT"; h.eventAt=System.currentTimeMillis(); AppDatabase.get(context).dao().addHistory(h);
   if(interval>0 && (until==0 || System.currentTimeMillis()+interval<=until)){ task.dueAt=System.currentTimeMillis()+interval; AppDatabase.get(context).dao().updateTask(task); AlarmScheduler.schedule(context,task); }
  });
 }
 private void createChannel(Context c){ if(Build.VERSION.SDK_INT>=26){ NotificationChannel ch=new NotificationChannel(CHANNEL,"Task reminders",NotificationManager.IMPORTANCE_HIGH); ch.setDescription("Scheduled reminders from DarkTodo"); NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE); if(nm!=null)nm.createNotificationChannel(ch); } }
}
