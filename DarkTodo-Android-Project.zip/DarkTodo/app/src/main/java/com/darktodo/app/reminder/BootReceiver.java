package com.darktodo.app.reminder;
import android.content.*; import com.darktodo.app.data.*;
public class BootReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){ AppDatabase.databaseWriteExecutor.execute(()->{ for(TaskEntity t:AppDatabase.get(c).dao().activeTasks()) AlarmScheduler.schedule(c,t); }); } }
