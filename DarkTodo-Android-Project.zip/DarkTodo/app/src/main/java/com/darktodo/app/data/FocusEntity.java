package com.darktodo.app.data;
import androidx.room.Entity; import androidx.room.PrimaryKey;
@Entity(tableName="focus_sessions")
public class FocusEntity { @PrimaryKey(autoGenerate=true) public long id; public String subject; public long startedAt; public long durationMillis; }
