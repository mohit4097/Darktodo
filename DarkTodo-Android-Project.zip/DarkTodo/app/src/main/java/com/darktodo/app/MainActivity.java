package com.darktodo.app;

import android.Manifest; import android.app.*; import android.content.*; import android.content.pm.PackageManager; import android.os.*; import android.text.InputType; import android.view.*; import android.widget.*;
import androidx.annotation.*; import androidx.appcompat.app.AppCompatActivity; import androidx.core.app.ActivityCompat; import androidx.core.content.ContextCompat; import androidx.drawerlayout.widget.DrawerLayout; import androidx.recyclerview.widget.*;
import com.google.android.material.bottomnavigation.BottomNavigationView; import com.google.android.material.navigation.NavigationView; import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.darktodo.app.data.*; import com.darktodo.app.reminder.*; import com.darktodo.app.ui.MiniBarChart; import java.text.DateFormat; import java.util.*;

public class MainActivity extends AppCompatActivity {
 private AppDatabase db; private LinearLayout page; private String current="Home"; private DrawerLayout drawer; private TextView title; private int cyan=0xFF65A8FF, white=0xFFF4F6FF, muted=0xFF9AA8C2, card=0xFF151D31, bg=0xFF090E1B, violet=0xFF9B83FF, green=0xFF54D6A2; private boolean lightMode=false; private boolean lockDialogShowing=false; private long backgroundAt=0;
 @Override protected void onCreate(Bundle b){super.onCreate(b);lightMode=getPreferences(0).getBoolean("light_mode",false);if(lightMode){cyan=0xFF386DE8;white=0xFF182238;muted=0xFF64718A;card=0xFFFFFFFF;bg=0xFFF3F6FC;}setContentView(R.layout.activity_main);getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);findViewById(R.id.contentFrame).setBackgroundColor(bg);((ViewGroup)findViewById(R.id.drawer)).getChildAt(0).setBackgroundColor(bg);db=AppDatabase.get(this);drawer=findViewById(R.id.drawer);title=findViewById(R.id.toolbarTitle);findViewById(R.id.menuButton).setOnClickListener(v->drawer.openDrawer(Gravity.LEFT));findViewById(R.id.searchButton).setOnClickListener(v->search());
  BottomNavigationView bottom=findViewById(R.id.bottomNav); bottom.setOnItemSelectedListener(item->{navigate(label(item.getItemId()));return true;}); NavigationView nav=findViewById(R.id.navigationView);nav.setNavigationItemSelectedListener(item->{navigate(label(item.getItemId()));drawer.closeDrawer(Gravity.LEFT);return true;});
  if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},33);
  navigate("Home"); checkLock();
 }
 private String label(int id) {
  if (id == R.id.nav_tasks) return "Tasks";
  if (id == R.id.nav_planner) return "Planner";
  if (id == R.id.nav_insights) return "Insights";
  if (id == R.id.nav_more) return "More";
  if (id == R.id.nav_notifications) return "Notifications";
  if (id == R.id.nav_academic) return "Academic Planner";
  if (id == R.id.nav_focus) return "Focus Timer";
  if (id == R.id.nav_habits) return "Habits";
  if (id == R.id.nav_notes) return "Notes";
  if (id == R.id.nav_task_history) return "Task History";
  if (id == R.id.nav_notification_history) return "Notification History";
  if (id == R.id.nav_focus_history) return "Focus History";
  if (id == R.id.nav_settings) return "Settings";
  return "Home";
 }
 private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density+0.5f);}
 private android.graphics.drawable.GradientDrawable shape(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(dp(radius));return d;}
 private void navigate(String p){current=p;title.setText("DARKTODO   /   "+p.toUpperCase(Locale.ROOT));LinearLayout root=findViewById(R.id.contentFrame);root.removeAllViews();ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);scroll.setPadding(0,0,0,dp(18));page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(dp(18),dp(16),dp(18),dp(26));scroll.addView(page);root.addView(scroll);if(p.equals("Home"))home();else if(p.equals("Tasks"))tasks(false);else if(p.equals("Task History"))tasks(true);else if(p.equals("Notifications")||p.equals("Notification History"))history();else if(p.equals("Notes"))notes();else if(p.equals("Insights"))insights();else if(p.equals("Focus Timer"))focus();else if(p.equals("Habits"))habits();else if(p.equals("Settings"))settings();else if(p.equals("Planner")||p.equals("Academic Planner"))planner(p);else if(p.equals("More"))more();else simple(p,"Your workspace, organized in one place.");}
 private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setFontFeatureSettings("kern");t.setPadding(0,dp(4),0,dp(4));t.setIncludeFontPadding(true);return t;}
 private void heading(String s){TextView t=text(s,25,white);t.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD));t.setPadding(0,dp(7),0,dp(3));page.addView(t);}
 private void sub(String s){TextView t=text(s,14,muted);t.setPadding(0,0,0,dp(12));page.addView(t);}
 private LinearLayout cardBox(){LinearLayout c=new LinearLayout(this);c.setOrientation(LinearLayout.VERTICAL);c.setPadding(dp(16),dp(15),dp(16),dp(15));c.setBackground(shape(card,20));return c;}
 private void gap(int h){View v=new View(this);page.addView(v,new LinearLayout.LayoutParams(1,dp(h)));}
 private TextView button(String s,Runnable r){TextView b=text(s,15,white);b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);b.setGravity(Gravity.CENTER_VERTICAL);b.setPadding(dp(17),dp(14),dp(17),dp(14));b.setBackground(shape(lightMode?0xFFE8EEFA:0xFF202D49,15));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(7));page.addView(b,lp);b.setOnClickListener(v->r.run());return b;}
 private void home(){
  TextView eyebrow=text("MONDAY  •  YOUR PERSONAL WORKSPACE",11,cyan);eyebrow.setLetterSpacing(.12f);eyebrow.setTypeface(null,1);page.addView(eyebrow);
  TextView hero=text("Make today\ncount.",34,white);hero.setTypeface(android.graphics.Typeface.create("sans-serif",android.graphics.Typeface.BOLD));hero.setLineSpacing(0,1.02f);page.addView(hero);
  sub(DateFormat.getDateInstance(DateFormat.FULL).format(new Date()));
  LinearLayout progress=cardBox();TextView pl=text("TODAY'S PROGRESS",11,muted);pl.setTypeface(null,1);progress.addView(pl);TextView percent=text("0%",30,white);percent.setTypeface(null,1);progress.addView(percent);TextView hint=text("A clear plan makes a calmer day.",13,muted);progress.addView(hint);android.widget.ProgressBar bar=new android.widget.ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);bar.setMax(100);bar.setProgress(0);bar.setProgressTintList(android.content.res.ColorStateList.valueOf(cyan));bar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(lightMode?0xFFD8E0EF:0xFF303B55));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,dp(7));bp.topMargin=dp(14);progress.addView(bar,bp);page.addView(progress);
  gap(14);LinearLayout stats=row();stats.setWeightSum(2);LinearLayout pending=statTile("OPEN TASKS","—",cyan);LinearLayout completed=statTile("COMPLETED","—",green);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,-2,1);sp.rightMargin=dp(7);stats.addView(pending,sp);LinearLayout.LayoutParams sp2=new LinearLayout.LayoutParams(0,-2,1);sp2.leftMargin=dp(7);stats.addView(completed,sp2);page.addView(stats);
  AppDatabase.databaseWriteExecutor.execute(()->{int a=db.dao().pendingCount(),c=db.dao().completedCount(),total=a+c;runOnUiThread(()->{if(isFinishing()||isDestroyed())return;((TextView)pending.getChildAt(0)).setText(String.valueOf(a));((TextView)completed.getChildAt(0)).setText(String.valueOf(c));int pct=total==0?0:c*100/total;percent.setText(pct+"%");bar.setProgress(pct);});});
  gap(18);LinearLayout top=row();top.setGravity(Gravity.CENTER_VERTICAL);TextView h=text("Today's focus",21,white);h.setTypeface(null,1);top.addView(h,new LinearLayout.LayoutParams(0,-2,1));TextView see=text("VIEW ALL  →",11,cyan);see.setTypeface(null,1);top.addView(see);see.setOnClickListener(v->navigate("Tasks"));page.addView(top);sub("Your next steps, without the clutter.");
  LinearLayout quick=cardBox();quick.setOrientation(LinearLayout.HORIZONTAL);quick.setGravity(Gravity.CENTER_VERTICAL);TextView plus=text("＋",27,cyan);plus.setGravity(Gravity.CENTER);quick.addView(plus,new LinearLayout.LayoutParams(dp(42),dp(42)));LinearLayout qcopy=new LinearLayout(this);qcopy.setOrientation(LinearLayout.VERTICAL);TextView qt=text("Plan a new task",15,white);qt.setTypeface(null,1);qcopy.addView(qt);qcopy.addView(text("Set a deadline and reminder",12,muted));quick.addView(qcopy,new LinearLayout.LayoutParams(0,-2,1));quick.setOnClickListener(v->addTask());page.addView(quick);
  gap(10);loadTaskCards(false);
  gap(16);LinearLayout insight=cardBox();insight.setOrientation(LinearLayout.HORIZONTAL);TextView it=text("◈",25,violet);insight.addView(it);LinearLayout ic=new LinearLayout(this);ic.setOrientation(LinearLayout.VERTICAL);ic.setPadding(dp(12),0,0,0);TextView ititle=text("Your progress, in perspective",14,white);ititle.setTypeface(null,1);ic.addView(ititle);ic.addView(text("Explore your productivity insights",12,muted));insight.addView(ic);insight.setOnClickListener(v->navigate("Insights"));page.addView(insight);
 }
 private LinearLayout statTile(String label,String value,int accent){LinearLayout c=cardBox();TextView v=text(value,27,white);v.setTypeface(null,1);c.addView(v);TextView l=text(label,10,muted);l.setLetterSpacing(.08f);l.setTypeface(null,1);c.addView(l);return c;}
 private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
 private void addStat(LinearLayout l,String label,String val){LinearLayout c=cardBox();c.addView(text(val,25,white));c.addView(text(label,11,muted));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(0,dp(6),dp(6),dp(8));l.addView(c,p);}
 private void addTask(){LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);EditText name=new EditText(this);name.setHint("Task title");EditText detail=new EditText(this);detail.setHint("Details (optional)");form.addView(name);form.addView(detail);final Calendar cal=Calendar.getInstance();Button date=new Button(this);date.setText("Choose date & time");form.addView(date);final long[] due={System.currentTimeMillis()+3600000};date.setOnClickListener(v->{DatePickerDialog d=new DatePickerDialog(this,(x,y,m,day)->{cal.set(y,m,day);new TimePickerDialog(this,(z,h,min)->{cal.set(Calendar.HOUR_OF_DAY,h);cal.set(Calendar.MINUTE,min);due[0]=cal.getTimeInMillis();date.setText(DateFormat.getDateTimeInstance().format(new Date(due[0])));},cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),false).show();},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH));d.show();});Spinner repeat=new Spinner(this);String[] choices={"No repeat","Every 30 minutes","Every 1 hour","Every 2 hours","Every 3 hours","Every 6 hours","Every 12 hours","Every 24 hours"};repeat.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,choices));form.addView(repeat);new AlertDialog.Builder(this).setTitle("New mission").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{if(name.getText().toString().trim().isEmpty()){toast("Add a task title");return;}TaskEntity t=new TaskEntity();t.title=name.getText().toString().trim();t.details=detail.getText().toString();t.dueAt=due[0];t.createdAt=System.currentTimeMillis();int ix=repeat.getSelectedItemPosition();long[] intervals={0,1800000,3600000,7200000,10800000,21600000,43200000,86400000};t.intervalMillis=intervals[ix];t.repeatUntil=0;AppDatabase.databaseWriteExecutor.execute(()->{t.id=db.dao().insertTask(t);HistoryEntity h=new HistoryEntity();h.taskId=t.id;h.title=t.title;h.event="CREATED";h.eventAt=System.currentTimeMillis();db.dao().addHistory(h);AlarmScheduler.schedule(this,t);runOnUiThread(()->navigate("Tasks"));});}).show();}
 private void tasks(boolean completed) {
  heading(completed ? "Completed tasks" : "Your tasks");
  sub(completed ? "A record of missions you have finished." : "Plan, prioritize and complete your next steps.");
  button("＋  Create a task", () -> addTask());
  LinearLayout filters = row();
  TextView open = text("OPEN", 12, completed ? muted : cyan);
  TextView done = text("COMPLETED", 12, completed ? cyan : muted);
  open.setPadding(dp(12), dp(10), dp(12), dp(10));
  done.setPadding(dp(12), dp(10), dp(12), dp(10));
  filters.addView(open); filters.addView(done); page.addView(filters);
  open.setOnClickListener(v -> navigate("Tasks"));
  done.setOnClickListener(v -> navigate("Task History"));
  loadTaskCards(completed);
 }

 private void loadTaskCards(boolean completed) {
  final LinearLayout target = page;
  AppDatabase.databaseWriteExecutor.execute(() -> {
   List<TaskEntity> items = completed ? db.dao().completedTasks() : db.dao().activeTasks();
   runOnUiThread(() -> {
    if (target != page) return;
    if (items == null || items.isEmpty()) {
     TextView empty = text(completed ? "No completed tasks yet." : "Nothing scheduled yet. Add your first task.", 14, muted);
     LinearLayout emptyCard = cardBox(); emptyCard.addView(empty); target.addView(emptyCard);
     return;
    }
    for (TaskEntity task : items) {
     LinearLayout item = cardBox();
     TextView name = text(task.title == null ? "Untitled task" : task.title, 17, white);
     name.setTypeface(null, android.graphics.Typeface.BOLD);
     item.addView(name);
     if (task.details != null && !task.details.trim().isEmpty()) item.addView(text(task.details, 13, muted));
     item.addView(text(DateFormat.getDateTimeInstance().format(new Date(task.dueAt)), 12, muted));
     LinearLayout actions = row();
     if (!completed) {
      TextView finish = text("COMPLETE", 12, green);
      TextView pause = text(task.paused ? "RESUME" : "PAUSE", 12, cyan);
      TextView remove = text("DELETE", 12, 0xFFFF7188);
      finish.setPadding(0, dp(8), dp(16), dp(4)); pause.setPadding(0, dp(8), dp(16), dp(4)); remove.setPadding(0, dp(8), dp(8), dp(4));
      actions.addView(finish); actions.addView(pause); actions.addView(remove); item.addView(actions);
      finish.setOnClickListener(v -> complete(task));
      pause.setOnClickListener(v -> {
       task.paused = !task.paused;
       AppDatabase.databaseWriteExecutor.execute(() -> db.dao().updateTask(task));
       if (task.paused) AlarmScheduler.cancel(MainActivity.this, task.id); else AlarmScheduler.schedule(MainActivity.this, task);
       navigate(completed ? "Task History" : "Tasks");
      });
      remove.setOnClickListener(v -> new AlertDialog.Builder(MainActivity.this).setTitle("Delete task?").setMessage(task.title).setNegativeButton("Cancel", null).setPositiveButton("Delete", (d,w) -> {
       AlarmScheduler.cancel(MainActivity.this, task.id);
       AppDatabase.databaseWriteExecutor.execute(() -> { db.dao().deleteTask(task); runOnUiThread(() -> navigate("Tasks")); });
      }).show());
     } else {
      item.addView(text("COMPLETED", 11, green));
     }
     target.addView(item, new LinearLayout.LayoutParams(-1, -2));
     gap(8);
    }
   });
  });
 }

 private void complete(TaskEntity t){t.completed=true;AlarmScheduler.cancel(this,t.id);AppDatabase.databaseWriteExecutor.execute(()->{db.dao().updateTask(t);HistoryEntity h=new HistoryEntity();h.taskId=t.id;h.title=t.title;h.event="COMPLETED";h.eventAt=System.currentTimeMillis();db.dao().addHistory(h);runOnUiThread(()->navigate("Tasks"));});}
 private void history(){heading("Activity archive");sub("A timeline of reminders and task events.");AppDatabase.databaseWriteExecutor.execute(()->{List<HistoryEntity> hs=db.dao().history();runOnUiThread(()->{for(HistoryEntity h:hs)page.addView(text(h.event+"  ·  "+h.title+"\n"+DateFormat.getDateTimeInstance().format(new Date(h.eventAt)),14,white));if(hs.isEmpty())sub("No activity recorded yet.");});});}
 private void notes(){heading("Quick notes");button("＋  New note",()->{EditText e=new EditText(this);e.setHint("Write your note...");new AlertDialog.Builder(this).setTitle("New note").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{NoteEntity n=new NoteEntity();n.title="Quick note";n.body=e.getText().toString();n.updatedAt=System.currentTimeMillis();AppDatabase.databaseWriteExecutor.execute(()->{db.dao().insertNote(n);runOnUiThread(()->navigate("Notes"));});}).show();});AppDatabase.databaseWriteExecutor.execute(()->{List<NoteEntity> ns=db.dao().notes();runOnUiThread(()->{for(NoteEntity n:ns)page.addView(text(n.body+"\n"+DateFormat.getDateTimeInstance().format(new Date(n.updatedAt)),14,white));});});}
 private void insights(){heading("Productivity intelligence");sub("Live statistics calculated from your local database.");AppDatabase.databaseWriteExecutor.execute(()->{int done=db.dao().completedCount(),pending=db.dao().pendingCount();runOnUiThread(()->{page.addView(text("COMPLETED TASKS     "+done,19,0xFF4DDBA3));page.addView(text("PENDING TASKS       "+pending,19,cyan));int total=done+pending;page.addView(text("Completion rate       "+(total==0?0:(done*100/total))+"%",19,0xFF9875FF));page.addView(text("Task completion overview",16,white));page.addView(new MiniBarChart(this,new int[]{done,pending},new String[]{"Done","Pending"}),new LinearLayout.LayoutParams(-1,190));});});}
 private void focus(){heading("Focus session");sub("Choose a focused study block. Keep your phone quiet and make progress.");final int[] seconds={25*60};TextView timer=text("25:00",42,cyan);timer.setGravity(17);page.addView(timer);button("Start 25-minute focus",()->{new CountDownTimer(25*60*1000,1000){public void onTick(long ms){timer.setText(String.format(Locale.getDefault(),"%02d:%02d",ms/60000,(ms/1000)%60));}public void onFinish(){timer.setText("SESSION COMPLETE");}}.start();});button("Start 50-minute focus",()->{new CountDownTimer(50*60*1000,1000){public void onTick(long ms){timer.setText(String.format(Locale.getDefault(),"%02d:%02d",ms/60000,(ms/1000)%60));}public void onFinish(){timer.setText("SESSION COMPLETE");}}.start();});}
 private void habits(){heading("Habit tracker");sub("Build consistency one day at a time.");button("＋  Add a habit",()->{EditText e=new EditText(this);e.setHint("e.g. Read 20 minutes");new AlertDialog.Builder(this).setTitle("New habit").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{HabitEntity h=new HabitEntity();h.title=e.getText().toString();h.createdAt=System.currentTimeMillis();AppDatabase.databaseWriteExecutor.execute(()->db.dao().insertHabit(h));navigate("Habits");}).show();});AppDatabase.databaseWriteExecutor.execute(()->{List<HabitEntity> hs=db.dao().habits();runOnUiThread(()->{for(HabitEntity h:hs)button("◉  "+h.title+"   ·   "+h.streak+" day streak",()->{long today=System.currentTimeMillis()/86400000;if(h.lastCompletedDay!=today){h.streak++;h.lastCompletedDay=today;AppDatabase.databaseWriteExecutor.execute(()->db.dao().updateHabit(h));toast("Habit completed for today");}else toast("Already completed today");navigate("Habits");});});});}
 private void planner(String p){heading(p.equals("Planner")?"Your schedule":"Academic mission board");sub("Plan deadlines, classes, assignments and exam milestones.");button("＋  Add a dated task",()->addTask());button("View all tasks",()->navigate("Tasks"));}
 private void settings(){heading("Settings & security");sub("Your app. Your rules.");button("Enable / change PIN or password lock",()->setLock());button("Disable app lock",()->{try{androidx.security.crypto.MasterKey key=new androidx.security.crypto.MasterKey.Builder(this).setKeyScheme(androidx.security.crypto.MasterKey.KeyScheme.AES256_GCM).build();android.content.SharedPreferences pref=androidx.security.crypto.EncryptedSharedPreferences.create(this,"darktodo_secure",key,androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);pref.edit().remove("app_lock").apply();toast("App lock disabled");}catch(Exception ex){toast("Unable to update security settings");}});button("Switch appearance: "+(lightMode?"Light":"Dark"),()->{lightMode=!lightMode;cyan=lightMode?0xFF386DE8:0xFF65A8FF;white=lightMode?0xFF182238:0xFFF4F6FF;muted=lightMode?0xFF64718A:0xFF9AA8C2;card=lightMode?0xFFFFFFFF:0xFF151D31;bg=lightMode?0xFFF3F6FC:0xFF090E1B;getWindow().setStatusBarColor(bg);getWindow().setNavigationBarColor(bg);findViewById(R.id.contentFrame).setBackgroundColor(bg);findViewById(R.id.drawer).setBackgroundColor(bg);((ViewGroup)findViewById(R.id.drawer)).getChildAt(0).setBackgroundColor(bg);((BottomNavigationView)findViewById(R.id.bottomNav)).setBackgroundColor(card);getPreferences(0).edit().putBoolean("light_mode",lightMode).apply();navigate("Settings");});button("Request notification permission",()->{if(Build.VERSION.SDK_INT>=33)ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},33);});button("Local data & backup",()->toast("Local database is stored on this device. Export/restore is planned for the release build."));}
 private void setLock(){EditText pin=new EditText(this);pin.setHint("Create PIN or password");pin.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);new AlertDialog.Builder(this).setTitle("App lock setup").setMessage("This initial build stores a local lock credential. Use a unique code.").setView(pin).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{try{androidx.security.crypto.MasterKey key=new androidx.security.crypto.MasterKey.Builder(this).setKeyScheme(androidx.security.crypto.MasterKey.KeyScheme.AES256_GCM).build();android.content.SharedPreferences pref= androidx.security.crypto.EncryptedSharedPreferences.create(this,"darktodo_secure",key,androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);pref.edit().putString("app_lock",pin.getText().toString()).apply();toast("App lock enabled. It will be requested on next app entry.");}catch(Exception ex){toast("Could not initialize secure storage");}}).show();}
 private void more(){heading("More systems");for(String p:new String[]{"Notifications","Academic Planner","Focus Timer","Habits","Notes","Task History","Notification History","Settings"})button(p+"  →",()->navigate(p));}
 private void simple(String h,String body){heading(h);sub(body);}
 private void search(){EditText e=new EditText(this);e.setHint("Search tasks and notes");new AlertDialog.Builder(this).setTitle("Global search").setView(e).setPositiveButton("Search",(d,w)->{String q=e.getText().toString();navigate("Tasks");toast("Search term: "+q);}).setNegativeButton("Cancel",null).show();}

 private String storedLock(){try{androidx.security.crypto.MasterKey key=new androidx.security.crypto.MasterKey.Builder(this).setKeyScheme(androidx.security.crypto.MasterKey.KeyScheme.AES256_GCM).build();android.content.SharedPreferences pref=androidx.security.crypto.EncryptedSharedPreferences.create(this,"darktodo_secure",key,androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);return pref.getString("app_lock",null);}catch(Exception e){return null;}}
 private void checkLock(){String saved=storedLock();if(saved==null||saved.isEmpty()||lockDialogShowing)return;lockDialogShowing=true;EditText entry=new EditText(this);entry.setHint("Enter passcode");entry.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);AlertDialog dialog=new AlertDialog.Builder(this).setTitle("DARKTODO ACCESS").setMessage("Enter your app passcode to continue.").setView(entry).setCancelable(false).setPositiveButton("Unlock",null).create();dialog.setOnShowListener(x->dialog.getButton(-1).setOnClickListener(v->{if(saved.equals(entry.getText().toString())){lockDialogShowing=false;dialog.dismiss();}else{entry.setError("Incorrect passcode");}}));dialog.show();}
 @Override protected void onPause(){super.onPause();backgroundAt=System.currentTimeMillis();}
 @Override protected void onResume(){super.onResume();if(backgroundAt>0){backgroundAt=0;checkLock();}}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
