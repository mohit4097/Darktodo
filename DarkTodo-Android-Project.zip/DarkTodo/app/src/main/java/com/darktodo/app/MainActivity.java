package com.darktodo.app;

import android.Manifest; import android.app.*; import android.content.*; import android.content.pm.PackageManager; import android.os.*; import android.text.InputType; import android.view.*; import android.widget.*;
import androidx.annotation.*; import androidx.appcompat.app.AppCompatActivity; import androidx.core.app.ActivityCompat; import androidx.core.content.ContextCompat; import androidx.drawerlayout.widget.DrawerLayout; import androidx.recyclerview.widget.*;
import com.google.android.material.bottomnavigation.BottomNavigationView; import com.google.android.material.navigation.NavigationView; import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.darktodo.app.data.*; import com.darktodo.app.reminder.*; import com.darktodo.app.ui.MiniBarChart; import java.text.DateFormat; import java.util.*;

public class MainActivity extends AppCompatActivity {
 private AppDatabase db; private LinearLayout page; private String current="Home"; private DrawerLayout drawer; private TextView title; private final int cyan=0xFF35B8FF, white=0xFFF4F7FF, muted=0xFF9BAAC4, card=0xFF101A2C; private boolean lockDialogShowing=false; private long backgroundAt=0;
 @Override protected void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);db=AppDatabase.get(this);drawer=findViewById(R.id.drawer);title=findViewById(R.id.toolbarTitle);findViewById(R.id.menuButton).setOnClickListener(v->drawer.openDrawer(Gravity.LEFT));findViewById(R.id.searchButton).setOnClickListener(v->search());
  BottomNavigationView bottom=findViewById(R.id.bottomNav); bottom.setOnItemSelectedListener(item->{navigate(label(item.getItemId()));return true;}); NavigationView nav=findViewById(R.id.navigationView);nav.setNavigationItemSelectedListener(item->{navigate(label(item.getItemId()));drawer.closeDrawer(Gravity.LEFT);return true;});
  if(Build.VERSION.SDK_INT>=33 && ContextCompat.checkSelfPermission(this,Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},33);
  navigate("Home"); checkLock();
 }
 private String label(int id) {
  if (id == R.id.nav_tasks) return "Tasks";
  if (id == R.id.nav_planner) return "Planner";
  if (id == R.id.nav_insights) return "Insights";
  if (id == R.id.nav_more) return "More";
  if (id == R.id.nav_notifications) return "Notifications";
  if (id == R.id.nav_academic) return "Academic Planner";
  if (id == R.id.nav_focus) return "Focus Timer";
  if (id == R.id.nav_habits) return "Habits";
  if (id == R.id.nav_notes) return "Notes";
  if (id == R.id.nav_task_history) return "Task History";
  if (id == R.id.nav_notification_history) return "Notification History";
  if (id == R.id.nav_focus_history) return "Focus History";
  if (id == R.id.nav_settings) return "Settings";
  return "Home";
 }
 private void navigate(String p){current=p;title.setText("DARKTODO  /  "+p.toUpperCase(Locale.ROOT)); android.widget.FrameLayout root=findViewById(R.id.contentFrame);root.removeAllViews();page=new LinearLayout(this);page.setOrientation(LinearLayout.VERTICAL);page.setPadding(18,14,18,14);root.addView(page,new android.widget.FrameLayout.LayoutParams(-1,-1)); if(p.equals("Home"))home();else if(p.equals("Tasks"))tasks(false);else if(p.equals("Task History"))tasks(true);else if(p.equals("Notifications")||p.equals("Notification History"))history();else if(p.equals("Notes"))notes();else if(p.equals("Insights"))insights();else if(p.equals("Focus Timer"))focus();else if(p.equals("Habits"))habits();else if(p.equals("Settings"))settings();else if(p.equals("Planner")||p.equals("Academic Planner"))planner(p);else if(p.equals("More"))more();else simple(p,"Your workspace is ready for your entries."); }
 private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setPadding(0,6,0,6);return t;}
 private void heading(String s){page.addView(text(s,22,white));}
 private void sub(String s){page.addView(text(s,13,muted));}
 private TextView button(String s,Runnable r){TextView b=text(s,15,white);b.setBackgroundColor(0xFF17243A);b.setPadding(16,14,16,14);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,7,0,7);page.addView(b,lp);b.setOnClickListener(v->r.run());return b;}
 private void home(){heading("Your day. Under control.");sub(DateFormat.getDateInstance(DateFormat.FULL).format(new Date())); LinearLayout stats=row();addStat(stats,"MISSIONS","…");addStat(stats,"COMPLETED","…");page.addView(stats);AppDatabase.databaseWriteExecutor.execute(()->{int a=db.dao().pendingCount(),c=db.dao().completedCount();runOnUiThread(()->{((TextView)stats.getChildAt(0)).setText("MISSIONS\n"+a);((TextView)stats.getChildAt(1)).setText("COMPLETED\n"+c);});});heading("Today's missions");loadTaskCards(false);button("＋  Create a task",()->addTask());button("Open productivity insights  →",()->navigate("Insights")); }
 private LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);return l;}
 private void addStat(LinearLayout l,String label,String val){TextView t=text(label+"\n"+val,14,cyan);t.setBackgroundColor(card);t.setPadding(14,16,14,16);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(0,10,8,18);l.addView(t,p);}
 private void tasks(boolean completed){heading(completed?"Completed missions":"Task center");sub(completed?"Your completed work and milestones":"Create tasks, schedule reminders and track progress.");button("＋  Add new task",()->addTask());loadTaskCards(completed);}
 private void loadTaskCards(boolean completed) {
  AppDatabase.databaseWriteExecutor.execute(() -> {
   List<TaskEntity> list = completed ? db.dao().completedTasks() : db.dao().activeTasks();
   runOnUiThread(() -> {
    for (TaskEntity t : list) {
     LinearLayout box = new LinearLayout(this);
     box.setOrientation(LinearLayout.VERTICAL);
     box.setPadding(14, 10, 14, 10);
     box.setBackgroundColor(card);
     LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
     lp.setMargins(0, 5, 0, 5);
     page.addView(box, lp);
     TextView name = text((t.completed ? "✓  " : "◉  ") + t.title, 16, white);
     box.addView(name);
     box.addView(text(DateFormat.getDateTimeInstance().format(new Date(t.dueAt)), 12, muted));
     if (!completed) {
      LinearLayout actions = row();
      TextView done = text("COMPLETE", 12, 0xFF4DDBA3);
      TextView pause = text(t.paused ? "RESUME" : "PAUSE", 12, cyan);
      TextView del = text("DELETE", 12, 0xFFFF647C);
      actions.addView(done);
      actions.addView(pause);
      actions.addView(del);
      box.addView(actions);
      done.setOnClickListener(v -> complete(t));
      pause.setOnClickListener(v -> {
       t.paused = !t.paused;
       AppDatabase.databaseWriteExecutor.execute(() -> db.dao().updateTask(t));
       if (t.paused) AlarmScheduler.cancel(this, t.id);
       else AlarmScheduler.schedule(this, t);
       navigate("Tasks");
      });
      del.setOnClickListener(v -> {
       AlarmScheduler.cancel(this, t.id);
       AppDatabase.databaseWriteExecutor.execute(() -> {
        db.dao().deleteTask(t);
        runOnUiThread(() -> navigate("Tasks"));
       });
      });
     }
    }
   });
  });
 }
 private void addTask(){LinearLayout form=new LinearLayout(this);form.setOrientation(LinearLayout.VERTICAL);EditText name=new EditText(this);name.setHint("Task title");EditText detail=new EditText(this);detail.setHint("Details (optional)");form.addView(name);form.addView(detail);final Calendar cal=Calendar.getInstance();Button date=new Button(this);date.setText("Choose date & time");form.addView(date);final long[] due={System.currentTimeMillis()+3600000};date.setOnClickListener(v->{DatePickerDialog d=new DatePickerDialog(this,(x,y,m,day)->{cal.set(y,m,day);new TimePickerDialog(this,(z,h,min)->{cal.set(Calendar.HOUR_OF_DAY,h);cal.set(Calendar.MINUTE,min);due[0]=cal.getTimeInMillis();date.setText(DateFormat.getDateTimeInstance().format(new Date(due[0])));},cal.get(Calendar.HOUR_OF_DAY),cal.get(Calendar.MINUTE),false).show();},cal.get(Calendar.YEAR),cal.get(Calendar.MONTH),cal.get(Calendar.DAY_OF_MONTH));d.show();});Spinner repeat=new Spinner(this);String[] choices={"No repeat","Every 30 minutes","Every 1 hour","Every 2 hours","Every 3 hours","Every 6 hours","Every 12 hours","Every 24 hours"};repeat.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,choices));form.addView(repeat);new AlertDialog.Builder(this).setTitle("New mission").setView(form).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{if(name.getText().toString().trim().isEmpty()){toast("Add a task title");return;}TaskEntity t=new TaskEntity();t.title=name.getText().toString().trim();t.details=detail.getText().toString();t.dueAt=due[0];t.createdAt=System.currentTimeMillis();int ix=repeat.getSelectedItemPosition();long[] intervals={0,1800000,3600000,7200000,10800000,21600000,43200000,86400000};t.intervalMillis=intervals[ix];t.repeatUntil=0;AppDatabase.databaseWriteExecutor.execute(()->{t.id=db.dao().insertTask(t);HistoryEntity h=new HistoryEntity();h.taskId=t.id;h.title=t.title;h.event="CREATED";h.eventAt=System.currentTimeMillis();db.dao().addHistory(h);AlarmScheduler.schedule(this,t);runOnUiThread(()->navigate("Tasks"));});}).show();}
 private void complete(TaskEntity t){t.completed=true;AlarmScheduler.cancel(this,t.id);AppDatabase.databaseWriteExecutor.execute(()->{db.dao().updateTask(t);HistoryEntity h=new HistoryEntity();h.taskId=t.id;h.title=t.title;h.event="COMPLETED";h.eventAt=System.currentTimeMillis();db.dao().addHistory(h);runOnUiThread(()->navigate("Tasks"));});}
 private void history(){heading("Activity archive");sub("A timeline of reminders and task events.");AppDatabase.databaseWriteExecutor.execute(()->{List<HistoryEntity> hs=db.dao().history();runOnUiThread(()->{for(HistoryEntity h:hs)page.addView(text(h.event+"  ·  "+h.title+"\n"+DateFormat.getDateTimeInstance().format(new Date(h.eventAt)),14,white));if(hs.isEmpty())sub("No activity recorded yet.");});});}
 private void notes(){heading("Quick notes");button("＋  New note",()->{EditText e=new EditText(this);e.setHint("Write your note...");new AlertDialog.Builder(this).setTitle("New note").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{NoteEntity n=new NoteEntity();n.title="Quick note";n.body=e.getText().toString();n.updatedAt=System.currentTimeMillis();AppDatabase.databaseWriteExecutor.execute(()->{db.dao().insertNote(n);runOnUiThread(()->navigate("Notes"));});}).show();});AppDatabase.databaseWriteExecutor.execute(()->{List<NoteEntity> ns=db.dao().notes();runOnUiThread(()->{for(NoteEntity n:ns)page.addView(text(n.body+"\n"+DateFormat.getDateTimeInstance().format(new Date(n.updatedAt)),14,white));});});}
 private void insights(){heading("Productivity intelligence");sub("Live statistics calculated from your local database.");AppDatabase.databaseWriteExecutor.execute(()->{int done=db.dao().completedCount(),pending=db.dao().pendingCount();runOnUiThread(()->{page.addView(text("COMPLETED TASKS     "+done,19,0xFF4DDBA3));page.addView(text("PENDING TASKS       "+pending,19,cyan));int total=done+pending;page.addView(text("Completion rate       "+(total==0?0:(done*100/total))+"%",19,0xFF9875FF));page.addView(text("Task completion overview",16,white));page.addView(new MiniBarChart(this,new int[]{done,pending},new String[]{"Done","Pending"}),new LinearLayout.LayoutParams(-1,190));});});}
 private void focus(){heading("Focus session");sub("Choose a focused study block. Keep your phone quiet and make progress.");final int[] seconds={25*60};TextView timer=text("25:00",42,cyan);timer.setGravity(17);page.addView(timer);button("Start 25-minute focus",()->{new CountDownTimer(25*60*1000,1000){public void onTick(long ms){timer.setText(String.format(Locale.getDefault(),"%02d:%02d",ms/60000,(ms/1000)%60));}public void onFinish(){timer.setText("SESSION COMPLETE");}}.start();});button("Start 50-minute focus",()->{new CountDownTimer(50*60*1000,1000){public void onTick(long ms){timer.setText(String.format(Locale.getDefault(),"%02d:%02d",ms/60000,(ms/1000)%60));}public void onFinish(){timer.setText("SESSION COMPLETE");}}.start();});}
 private void habits(){heading("Habit tracker");sub("Build consistency one day at a time.");button("＋  Add a habit",()->{EditText e=new EditText(this);e.setHint("e.g. Read 20 minutes");new AlertDialog.Builder(this).setTitle("New habit").setView(e).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{HabitEntity h=new HabitEntity();h.title=e.getText().toString();h.createdAt=System.currentTimeMillis();AppDatabase.databaseWriteExecutor.execute(()->db.dao().insertHabit(h));navigate("Habits");}).show();});AppDatabase.databaseWriteExecutor.execute(()->{List<HabitEntity> hs=db.dao().habits();runOnUiThread(()->{for(HabitEntity h:hs)button("◉  "+h.title+"   ·   "+h.streak+" day streak",()->{long today=System.currentTimeMillis()/86400000;if(h.lastCompletedDay!=today){h.streak++;h.lastCompletedDay=today;AppDatabase.databaseWriteExecutor.execute(()->db.dao().updateHabit(h));toast("Habit completed for today");}else toast("Already completed today");navigate("Habits");});});});}
 private void planner(String p){heading(p.equals("Planner")?"Your schedule":"Academic mission board");sub("Plan deadlines, classes, assignments and exam milestones.");button("＋  Add a dated task",()->addTask());button("View all tasks",()->navigate("Tasks"));}
 private void settings(){heading("Settings & security");sub("Your app. Your rules.");button("Enable / change PIN or password lock",()->setLock());button("Disable app lock",()->{try{androidx.security.crypto.MasterKey key=new androidx.security.crypto.MasterKey.Builder(this).setKeyScheme(androidx.security.crypto.MasterKey.KeyScheme.AES256_GCM).build();android.content.SharedPreferences pref=androidx.security.crypto.EncryptedSharedPreferences.create(this,"darktodo_secure",key,androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);pref.edit().remove("app_lock").apply();toast("App lock disabled");}catch(Exception ex){toast("Unable to update security settings");}});button("Appearance: Dark navy",()->toast("Dark theme is active"));button("Request notification permission",()->{if(Build.VERSION.SDK_INT>=33)ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.POST_NOTIFICATIONS},33);});button("Local data & backup",()->toast("Local database is stored on this device. Export/restore is planned for the release build."));}
 private void setLock(){EditText pin=new EditText(this);pin.setHint("Create PIN or password");pin.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);new AlertDialog.Builder(this).setTitle("App lock setup").setMessage("This initial build stores a local lock credential. Use a unique code.").setView(pin).setNegativeButton("Cancel",null).setPositiveButton("Save",(d,w)->{try{androidx.security.crypto.MasterKey key=new androidx.security.crypto.MasterKey.Builder(this).setKeyScheme(androidx.security.crypto.MasterKey.KeyScheme.AES256_GCM).build();android.content.SharedPreferences pref= androidx.security.crypto.EncryptedSharedPreferences.create(this,"darktodo_secure",key,androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);pref.edit().putString("app_lock",pin.getText().toString()).apply();toast("App lock enabled. It will be requested on next app entry.");}catch(Exception ex){toast("Could not initialize secure storage");}}).show();}
 private void more(){heading("More systems");for(String p:new String[]{"Notifications","Academic Planner","Focus Timer","Habits","Notes","Task History","Notification History","Settings"})button(p+"  →",()->navigate(p));}
 private void simple(String h,String body){heading(h);sub(body);}
 private void search(){EditText e=new EditText(this);e.setHint("Search tasks and notes");new AlertDialog.Builder(this).setTitle("Global search").setView(e).setPositiveButton("Search",(d,w)->{String q=e.getText().toString();navigate("Tasks");toast("Search term: "+q);}).setNegativeButton("Cancel",null).show();}

 private String storedLock(){try{androidx.security.crypto.MasterKey key=new androidx.security.crypto.MasterKey.Builder(this).setKeyScheme(androidx.security.crypto.MasterKey.KeyScheme.AES256_GCM).build();android.content.SharedPreferences pref=androidx.security.crypto.EncryptedSharedPreferences.create(this,"darktodo_secure",key,androidx.security.crypto.EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,androidx.security.crypto.EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM);return pref.getString("app_lock",null);}catch(Exception e){return null;}}
 private void checkLock(){String saved=storedLock();if(saved==null||saved.isEmpty()||lockDialogShowing)return;lockDialogShowing=true;EditText entry=new EditText(this);entry.setHint("Enter passcode");entry.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD);AlertDialog dialog=new AlertDialog.Builder(this).setTitle("DARKTODO ACCESS").setMessage("Enter your app passcode to continue.").setView(entry).setCancelable(false).setPositiveButton("Unlock",null).create();dialog.setOnShowListener(x->dialog.getButton(-1).setOnClickListener(v->{if(saved.equals(entry.getText().toString())){lockDialogShowing=false;dialog.dismiss();}else{entry.setError("Incorrect passcode");}}));dialog.show();}
 @Override protected void onPause(){super.onPause();backgroundAt=System.currentTimeMillis();}
 @Override protected void onResume(){super.onResume();if(backgroundAt>0){backgroundAt=0;checkLock();}}
 private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
