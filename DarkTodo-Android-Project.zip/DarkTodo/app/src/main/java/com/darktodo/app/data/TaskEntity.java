package com.darktodo.app.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "tasks")
public class TaskEntity {
    @PrimaryKey(autoGenerate = true) public long id;
    public String title;
    public String details;
    public long dueAt;
    public long intervalMillis;
    public long repeatUntil;
    public int priority;
    public boolean completed;
    public boolean paused;
    public long createdAt;
}
