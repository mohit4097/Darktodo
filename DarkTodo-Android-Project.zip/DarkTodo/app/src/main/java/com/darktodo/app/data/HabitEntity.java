package com.darktodo.app.data;
import androidx.room.Entity; import androidx.room.PrimaryKey;
@Entity(tableName="habits")
public class HabitEntity { @PrimaryKey(autoGenerate=true) public long id; public String title; public long createdAt; public int streak; public long lastCompletedDay; }
