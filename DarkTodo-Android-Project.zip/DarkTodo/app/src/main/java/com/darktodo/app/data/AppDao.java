package com.darktodo.app.data;
import androidx.room.*; import java.util.List;
@Dao public interface AppDao {
 @Query("SELECT * FROM tasks WHERE completed=0 AND paused=0 ORDER BY dueAt ASC") List<TaskEntity> activeTasks();
 @Query("SELECT * FROM tasks WHERE id=:id LIMIT 1") TaskEntity taskById(long id);
 @Query("SELECT * FROM tasks ORDER BY createdAt DESC") List<TaskEntity> allTasks();
 @Query("SELECT * FROM tasks WHERE completed=1 ORDER BY createdAt DESC") List<TaskEntity> completedTasks();
 @Insert long insertTask(TaskEntity t); @Update void updateTask(TaskEntity t); @Delete void deleteTask(TaskEntity t);
 @Insert void addHistory(HistoryEntity h); @Query("SELECT * FROM history ORDER BY eventAt DESC LIMIT 500") List<HistoryEntity> history();
 @Insert long insertNote(NoteEntity n); @Update void updateNote(NoteEntity n); @Query("SELECT * FROM notes ORDER BY updatedAt DESC") List<NoteEntity> notes();
 @Insert long insertHabit(HabitEntity h); @Update void updateHabit(HabitEntity h); @Query("SELECT * FROM habits ORDER BY createdAt DESC") List<HabitEntity> habits();
 @Insert void insertFocus(FocusEntity f); @Query("SELECT * FROM focus_sessions ORDER BY startedAt DESC") List<FocusEntity> focusSessions();
 @Query("SELECT COUNT(*) FROM tasks WHERE completed=1") int completedCount(); @Query("SELECT COUNT(*) FROM tasks WHERE completed=0") int pendingCount();
}
