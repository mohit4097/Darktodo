package com.darktodo.app.data;
import android.content.Context; import java.util.concurrent.ExecutorService; import java.util.concurrent.Executors; import androidx.room.Database; import androidx.room.Room; import androidx.room.RoomDatabase;
@Database(entities={TaskEntity.class,HistoryEntity.class,NoteEntity.class,HabitEntity.class,FocusEntity.class},version=1,exportSchema=false)
public abstract class AppDatabase extends RoomDatabase {
 public static final ExecutorService databaseWriteExecutor=Executors.newFixedThreadPool(2); private static volatile AppDatabase INSTANCE; public abstract AppDao dao();
 public static AppDatabase get(Context c){ if(INSTANCE==null){ synchronized(AppDatabase.class){ if(INSTANCE==null) INSTANCE=Room.databaseBuilder(c.getApplicationContext(),AppDatabase.class,"darktodo_local.db").build(); }} return INSTANCE; }
}
