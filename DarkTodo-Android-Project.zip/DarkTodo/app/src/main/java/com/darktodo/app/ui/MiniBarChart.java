package com.darktodo.app.ui;
import android.content.Context; import android.graphics.Canvas; import android.graphics.Paint; import android.graphics.RectF; import android.view.View;
public class MiniBarChart extends View {
 private final Paint p=new Paint(3); private final int[] values; private final String[] labels;
 public MiniBarChart(Context c,int[] v,String[] l){super(c);values=v;labels=l;setMinimumHeight(190);}
 @Override protected void onDraw(Canvas c){super.onDraw(c);float w=getWidth(),h=getHeight(),base=h-34; p.setColor(0xFF24344F);p.setStrokeWidth(1);c.drawLine(12,base,w-12,base,p);int max=1;for(int x:values)max=Math.max(max,x);float slot=(w-32f)/Math.max(1,values.length);for(int i=0;i<values.length;i++){float bh=(base-28)*(values[i]/(float)max);float left=18+i*slot+slot*.2f;RectF r=new RectF(left,base-bh,left+slot*.58f,base);p.setShader(new android.graphics.LinearGradient(0,base-bh,0,base,0xFF35B8FF,0xFF9875FF,android.graphics.Shader.TileMode.CLAMP));c.drawRoundRect(r,9,9,p);p.setShader(null);p.setColor(0xFF9BAAC4);p.setTextSize(10);c.drawText(labels[i],left-2, h-12,p);p.setColor(0xFF24344F);}}
}
