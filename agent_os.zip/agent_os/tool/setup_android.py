"""Patches the freshly generated Android project for AGENT.OS.

- Enables core library desugaring (needed by flutter_local_notifications)
- Adds notification / alarm permissions and receivers to AndroidManifest.xml
- Sets the launcher label
Works with both build.gradle.kts and build.gradle templates.
"""
import pathlib
import re
import sys

DESUGAR_VERSION = "2.1.4"
app = pathlib.Path("android/app")


def patch_gradle():
    kts = app / "build.gradle.kts"
    groovy = app / "build.gradle"
    if kts.exists():
        path, is_kts = kts, True
    elif groovy.exists():
        path, is_kts = groovy, False
    else:
        sys.exit("No app build.gradle(.kts) found")

    s = path.read_text()
    if "oreLibraryDesugaring" in s:
        print("gradle already patched")
        return

    flag = "isCoreLibraryDesugaringEnabled = true" if is_kts else "coreLibraryDesugaringEnabled true"
    s, n = re.subn(r"(compileOptions\s*\{)", r"\1\n        " + flag, s, count=1)
    if n == 0:
        # no compileOptions block: add one inside android { }
        s, n = re.subn(
            r"(android\s*\{)",
            r"\1\n    compileOptions {\n        " + flag + "\n    }",
            s,
            count=1,
        )
    if n == 0:
        sys.exit("Could not add compileOptions")

    if is_kts:
        dep = f'    coreLibraryDesugaring("com.android.tools:desugar_jdk_libs:{DESUGAR_VERSION}")'
    else:
        dep = f"    coreLibraryDesugaring 'com.android.tools:desugar_jdk_libs:{DESUGAR_VERSION}'"

    if re.search(r"^dependencies\s*\{", s, flags=re.M):
        s = re.sub(r"^dependencies\s*\{", "dependencies {\n" + dep, s, count=1, flags=re.M)
    else:
        s += "\ndependencies {\n" + dep + "\n}\n"

    path.write_text(s)
    print("patched", path)


def patch_manifest():
    path = app / "src/main/AndroidManifest.xml"
    s = path.read_text()
    if "ScheduledNotificationReceiver" in s:
        print("manifest already patched")
        return

    perms = """    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
    <uses-permission android:name="android.permission.WAKE_LOCK"/>
"""
    receivers = """        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON" />
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
"""
    s = s.replace("<application", perms + "    <application", 1)
    s = s.replace("</application>", receivers + "    </application>", 1)
    s = re.sub(r'android:label="[^"]*"', 'android:label="Agent OS"', s, count=1)
    path.write_text(s)
    print("patched manifest")


patch_gradle()
patch_manifest()
