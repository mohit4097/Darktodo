import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../core/theme.dart';

TextStyle ts(double size, {FontWeight w = FontWeight.w500, Color c = C.text, bool m = false, double ls = 0}) =>
    TextStyle(fontSize: size, fontWeight: w, color: c, letterSpacing: ls, fontFamily: m ? kMono : null);

InputDecoration deco(String label, {String? hint, IconData? icon}) {
  OutlineInputBorder b(Color c) =>
      OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide(color: c));
  return InputDecoration(
    labelText: label,
    hintText: hint,
    prefixIcon: icon == null ? null : Icon(icon, size: 20, color: C.dim),
    filled: true,
    fillColor: C.surface2,
    labelStyle: ts(13, c: C.dim),
    hintStyle: ts(13, c: C.dim),
    border: b(C.line),
    enabledBorder: b(C.line),
    focusedBorder: b(C.cyan),
  );
}

String fmtDT(DateTime d) => DateFormat('EEE, d MMM • h:mm a').format(d);
String fmtTimeOfDay(int minutes) =>
    DateFormat('h:mm a').format(DateTime(2000, 1, 1, minutes ~/ 60, minutes % 60));

String repeatLabel(int m) {
  if (m <= 0) return 'Once';
  if (m == 1440) return 'Daily';
  if (m < 60) return 'Every $m min';
  if (m % 60 == 0) return 'Every ${m ~/ 60} hr';
  return 'Every $m min';
}

String countdown(DateTime at) {
  final d = at.difference(DateTime.now());
  if (d.isNegative) return 'now';
  if (d.inDays >= 1) return '${d.inDays}d ${d.inHours % 24}h';
  if (d.inHours >= 1) return '${d.inHours}h ${d.inMinutes % 60}m';
  return '${d.inMinutes}m';
}

class HudCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets padding;
  final EdgeInsets margin;
  final Color accent;
  final VoidCallback? onTap;
  const HudCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(16),
    this.margin = EdgeInsets.zero,
    this.accent = C.cyan,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(16);
    return Padding(
      padding: margin,
      child: Material(
        color: Colors.transparent,
        child: Ink(
          decoration: BoxDecoration(
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [C.surface2, C.surface],
            ),
            borderRadius: r,
            border: Border.all(color: accent.withOpacity(0.28)),
          ),
          child: InkWell(
            borderRadius: r,
            onTap: onTap,
            child: Padding(padding: padding, child: child),
          ),
        ),
      ),
    );
  }
}

class SectionHeader extends StatelessWidget {
  final String title;
  final Widget? trailing;
  const SectionHeader(this.title, {super.key, this.trailing});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(2, 18, 2, 10),
        child: Row(children: [
          Container(width: 3, height: 14, color: C.cyan),
          const SizedBox(width: 8),
          Text(title.toUpperCase(), style: ts(12, c: C.dim, m: true, ls: 2, w: FontWeight.w700)),
          const Spacer(),
          if (trailing != null) trailing!,
        ]),
      );
}

class StatTile extends StatelessWidget {
  final String label;
  final String value;
  final IconData icon;
  final Color color;
  const StatTile({super.key, required this.label, required this.value, required this.icon, required this.color});

  @override
  Widget build(BuildContext context) => HudCard(
        accent: color,
        padding: const EdgeInsets.all(14),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Icon(icon, color: color, size: 22),
          const SizedBox(height: 10),
          Text(value, style: ts(26, w: FontWeight.w800, c: color, m: true)),
          const SizedBox(height: 2),
          Text(label.toUpperCase(), style: ts(10.5, c: C.dim, m: true, ls: 1.2)),
        ]),
      );
}

class EmptyState extends StatelessWidget {
  final IconData icon;
  final String text;
  const EmptyState(this.icon, this.text, {super.key});

  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 48),
        child: Center(
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 48, color: C.line),
            const SizedBox(height: 12),
            Text(text, textAlign: TextAlign.center, style: ts(13, c: C.dim, m: true)),
          ]),
        ),
      );
}

class NeonButton extends StatelessWidget {
  final String label;
  final IconData? icon;
  final VoidCallback? onTap;
  final Color color;
  const NeonButton(this.label, {super.key, this.icon, this.onTap, this.color = C.cyan});

  @override
  Widget build(BuildContext context) => FilledButton(
        onPressed: onTap,
        style: FilledButton.styleFrom(
          backgroundColor: color,
          foregroundColor: Colors.black,
          disabledBackgroundColor: C.line,
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
        ),
        child: Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          if (icon != null) ...[Icon(icon, size: 20), const SizedBox(width: 8)],
          Text(label, style: ts(14, w: FontWeight.w800, c: Colors.black, m: true, ls: 1.5)),
        ]),
      );
}

class ChipRow<T> extends StatelessWidget {
  final List<T> values;
  final T selected;
  final String Function(T) label;
  final ValueChanged<T> onChanged;
  final Color color;
  const ChipRow({
    super.key,
    required this.values,
    required this.selected,
    required this.label,
    required this.onChanged,
    this.color = C.cyan,
  });

  @override
  Widget build(BuildContext context) => Wrap(
        spacing: 8,
        runSpacing: 8,
        children: [
          for (final v in values)
            ChoiceChip(
              label: Text(label(v), style: ts(12.5, c: v == selected ? color : C.dim, w: FontWeight.w700)),
              selected: v == selected,
              showCheckmark: false,
              selectedColor: color.withOpacity(0.18),
              backgroundColor: C.surface2,
              side: BorderSide(color: v == selected ? color : C.line),
              onSelected: (_) => onChanged(v),
            ),
        ],
      );
}

Future<T?> showSheet<T>(BuildContext context, Widget Function(BuildContext) builder) {
  return showModalBottomSheet<T>(
    context: context,
    isScrollControlled: true,
    backgroundColor: C.surface,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (ctx) => Padding(
      padding: EdgeInsets.fromLTRB(20, 12, 20, 20 + MediaQuery.of(ctx).viewInsets.bottom),
      child: SingleChildScrollView(
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Center(
            child: Container(
              width: 40,
              height: 4,
              margin: const EdgeInsets.only(bottom: 16),
              decoration: BoxDecoration(color: C.line, borderRadius: BorderRadius.circular(2)),
            ),
          ),
          builder(ctx),
        ]),
      ),
    ),
  );
}

Future<DateTime?> pickDateTime(BuildContext context, DateTime initial) async {
  final d = await showDatePicker(
    context: context,
    initialDate: initial,
    firstDate: DateTime(2020),
    lastDate: DateTime.now().add(const Duration(days: 365 * 3)),
  );
  if (d == null) return null;
  if (!context.mounted) return null;
  final t = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(initial));
  if (t == null) return null;
  return DateTime(d.year, d.month, d.day, t.hour, t.minute);
}

void toast(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(SnackBar(
      content: Text(msg, style: ts(13, m: true)),
      backgroundColor: C.surface2,
      behavior: SnackBarBehavior.floating,
    ));
}

/// Tappable date/time field used in forms.
class DateTimeField extends StatelessWidget {
  final String label;
  final DateTime value;
  final ValueChanged<DateTime> onChanged;
  const DateTimeField({super.key, required this.label, required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () async {
          final r = await pickDateTime(context, value);
          if (r != null) onChanged(r);
        },
        child: InputDecorator(
          decoration: deco(label, icon: Icons.event),
          child: Text(fmtDT(value), style: ts(14, m: true)),
        ),
      );
}
