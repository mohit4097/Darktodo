import 'dart:math';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import '../core/theme.dart';
import 'widgets.dart';

FlTitlesData _titles(List<String> labels) {
  final none = AxisTitles(sideTitles: SideTitles(showTitles: false));
  return FlTitlesData(
    leftTitles: none,
    rightTitles: none,
    topTitles: none,
    bottomTitles: AxisTitles(
      sideTitles: SideTitles(
        showTitles: true,
        reservedSize: 26,
        interval: 1,
        getTitlesWidget: (v, meta) {
          final i = v.toInt();
          if (i < 0 || i >= labels.length) return const SizedBox.shrink();
          return Padding(
            padding: const EdgeInsets.only(top: 8),
            child: Text(labels[i], style: ts(11, c: C.dim, m: true)),
          );
        },
      ),
    ),
  );
}

double _maxY(List<double> v, double minTop) {
  final m = v.isEmpty ? 0.0 : v.reduce(max);
  return max(minTop, m * 1.25);
}

class MiniBar extends StatelessWidget {
  final List<double> values;
  final List<String> labels;
  final Color color;
  final double height;
  const MiniBar({super.key, required this.values, required this.labels, this.color = C.cyan, this.height = 150});

  @override
  Widget build(BuildContext context) {
    final top = _maxY(values, 4);
    return SizedBox(
      height: height,
      child: BarChart(BarChartData(
        maxY: top,
        alignment: BarChartAlignment.spaceAround,
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: top / 4,
          getDrawingHorizontalLine: (v) => FlLine(color: C.line, strokeWidth: 1),
        ),
        borderData: FlBorderData(show: false),
        titlesData: _titles(labels),
        barGroups: [
          for (var i = 0; i < values.length; i++)
            BarChartGroupData(x: i, barRods: [
              BarChartRodData(
                toY: values[i],
                width: 14,
                color: color,
                borderRadius: BorderRadius.circular(4),
                backDrawRodData: BackgroundBarChartRodData(show: true, toY: top, color: C.line.withOpacity(0.4)),
              ),
            ]),
        ],
      )),
    );
  }
}

class MiniLine extends StatelessWidget {
  final List<double> values;
  final List<String> labels;
  final Color color;
  final double height;
  const MiniLine({super.key, required this.values, required this.labels, this.color = C.violet, this.height = 150});

  @override
  Widget build(BuildContext context) {
    final top = _maxY(values, 30);
    return SizedBox(
      height: height,
      child: LineChart(LineChartData(
        minY: 0,
        maxY: top,
        minX: 0,
        maxX: (values.length - 1).toDouble(),
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: top / 4,
          getDrawingHorizontalLine: (v) => FlLine(color: C.line, strokeWidth: 1),
        ),
        borderData: FlBorderData(show: false),
        titlesData: _titles(labels),
        lineBarsData: [
          LineChartBarData(
            spots: [for (var i = 0; i < values.length; i++) FlSpot(i.toDouble(), values[i])],
            isCurved: true,
            color: color,
            barWidth: 3,
            dotData: FlDotData(show: true),
            belowBarData: BarAreaData(show: true, color: color.withOpacity(0.15)),
          ),
        ],
      )),
    );
  }
}

class Donut extends StatelessWidget {
  final List<double> values;
  final List<Color> colors;
  final Widget center;
  final double size;
  const Donut({super.key, required this.values, required this.colors, required this.center, this.size = 150});

  @override
  Widget build(BuildContext context) {
    final total = values.fold<double>(0, (a, b) => a + b);
    final sections = total <= 0
        ? [PieChartSectionData(value: 1, color: C.line, title: '', radius: 16)]
        : [
            for (var i = 0; i < values.length; i++)
              if (values[i] > 0) PieChartSectionData(value: values[i], color: colors[i], title: '', radius: 16),
          ];
    return SizedBox(
      width: size,
      height: size,
      child: Stack(alignment: Alignment.center, children: [
        PieChart(PieChartData(sections: sections, centerSpaceRadius: size / 2 - 18, sectionsSpace: 2)),
        center,
      ]),
    );
  }
}
