import 'package:flutter/material.dart';
import 'core/app_state.dart';
import 'core/notification_service.dart';
import 'core/theme.dart';
import 'pages/root_gate.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NotificationService.instance.init();
  await AppState.instance.init();
  final p = AppState.instance.prefs;
  if (!(p.getBool('asked_notif') ?? false)) {
    await p.setBool('asked_notif', true);
    NotificationService.instance.requestPermission();
  }
  runApp(const AgentApp());
}

class AgentApp extends StatelessWidget {
  const AgentApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'AGENT.OS',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(),
        home: const RootGate(),
      );
}
