import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../core/app_state.dart';
import '../core/theme.dart';
import '../ui/charts.dart';
import '../ui/widgets.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  String _greet() {
    final h = DateTime.now().hour;
    if (h < 12) return 'GOOD MORNING';
    if (h < 17) return 'GOOD AFTERNOON';
    return 'GOOD EVENING';
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppState.instance,
      builder: (context, _) {
        final s = AppState.instance;
        final up = s.upcoming().take(3).toList();
        final habitTotal = s.habits.length;
        final habitDone = s.habitsDoneToday;
        final nextExam = s.exams.where((e) => e.at.isAfter(DateTime.now())).toList();
        return SafeArea(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 24),
            children: [
              Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('${_greet()}, AGENT', style: ts(20, m: true, w: FontWeight.w800, ls: 1.5)),
                    const SizedBox(height: 4),
                    Text(DateFormat('EEEE, d MMMM').format(DateTime.now()).toUpperCase(),
                        style: ts(12, m: true, c: C.dim, ls: 1.5)),
                  ]),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    border: Border.all(color: C.green.withOpacity(0.6)),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Row(mainAxisSize: MainAxisSize.min, children: [
                    const Icon(Icons.circle, size: 8, color: C.green),
                    const SizedBox(width: 6),
                    Text('ONLINE', style: ts(10.5, m: true, c: C.green, ls: 1.5, w: FontWeight.w700)),
                  ]),
                ),
              ]),
              const SizedBox(height: 18),
              GridView.count(
                crossAxisCount: 2,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                mainAxisSpacing: 12,
                crossAxisSpacing: 12,
                childAspectRatio: 1.55,
                children: [
                  StatTile(label: 'Active missions', value: '${s.pendingCount}', icon: Icons.flag, color: C.cyan),
                  StatTile(label: 'Done today', value: '${s.doneToday}', icon: Icons.verified, color: C.green),
                  StatTile(label: 'Study today', value: '${s.studyToday}m', icon: Icons.menu_book, color: C.violet),
                  StatTile(label: 'Best streak', value: '${s.bestStreak}d', icon: Icons.local_fire_department, color: C.amber),
                ],
              ),
              const SectionHeader('Missions completed - 7 days'),
              HudCard(child: MiniBar(values: s.completedPerDay(7), labels: s.dayLabels(7), color: C.green)),
              const SectionHeader('Study minutes - 7 days'),
              HudCard(accent: C.violet, child: MiniLine(values: s.studyPerDay(7), labels: s.dayLabels(7))),
              const SectionHeader("Today's habits"),
              HudCard(
                accent: C.amber,
                child: Row(children: [
                  Donut(
                    size: 110,
                    values: [habitDone.toDouble(), (habitTotal - habitDone).toDouble()],
                    colors: const [C.amber, C.line],
                    center: Text(
                      habitTotal == 0 ? '-' : '${(habitDone * 100 / habitTotal).round()}%',
                      style: ts(20, m: true, w: FontWeight.w800, c: C.amber),
                    ),
                  ),
                  const SizedBox(width: 20),
                  Expanded(
                    child: Text(
                      habitTotal == 0
                          ? 'No habits yet. Add some in LAB > Habits.'
                          : '$habitDone of $habitTotal habits completed today.',
                      style: ts(14, c: C.dim),
                    ),
                  ),
                ]),
              ),
              if (nextExam.isNotEmpty) ...[
                const SectionHeader('Next exam'),
                HudCard(
                  accent: C.red,
                  child: Row(children: [
                    const Icon(Icons.school, color: C.red),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(nextExam.first.subject, style: ts(16, w: FontWeight.w700)),
                        Text(fmtDT(nextExam.first.at), style: ts(12, c: C.dim, m: true)),
                      ]),
                    ),
                    Text(countdown(nextExam.first.at), style: ts(20, m: true, c: C.red, w: FontWeight.w800)),
                  ]),
                ),
              ],
              const SectionHeader('Next alerts'),
              if (up.isEmpty)
                const EmptyState(Icons.notifications_none, 'Nothing scheduled.\nCreate a mission or an alert.')
              else
                for (final u in up)
                  HudCard(
                    margin: const EdgeInsets.only(bottom: 10),
                    padding: const EdgeInsets.all(14),
                    child: Row(children: [
                      Icon(_srcIcon(u.source), color: C.cyan, size: 20),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(u.title, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(14.5, w: FontWeight.w700)),
                          Text(fmtDT(u.at), style: ts(11.5, c: C.dim, m: true)),
                        ]),
                      ),
                      Text(countdown(u.at), style: ts(13, m: true, c: C.cyan, w: FontWeight.w700)),
                    ]),
                  ),
            ],
          ),
        );
      },
    );
  }
}

IconData _srcIcon(String s) {
  switch (s) {
    case 'task':
      return Icons.flag;
    case 'habit':
      return Icons.loop;
    case 'exam':
      return Icons.school;
    default:
      return Icons.notifications;
  }
}
