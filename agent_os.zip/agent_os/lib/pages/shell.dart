import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../ui/widgets.dart';
import 'alerts_page.dart';
import 'dashboard_page.dart';
import 'lab_page.dart';
import 'settings_page.dart';
import 'tasks_page.dart';

/// Main navigation for the normal space.
class Shell extends StatefulWidget {
  final VoidCallback onLock;
  const Shell({super.key, required this.onLock});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int _i = 0;

  @override
  Widget build(BuildContext context) {
    final pages = <Widget>[
      const DashboardPage(),
      const TasksPage(),
      const AlertsPage(),
      const LabPage(),
      SettingsPage(onLock: widget.onLock),
    ];
    Widget dest(IconData icon, String label) => NavigationDestination(
          icon: Icon(icon, color: C.dim),
          selectedIcon: Icon(icon, color: C.cyan),
          label: label,
        );
    return Scaffold(
      body: IndexedStack(index: _i, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _i,
        onDestinationSelected: (v) => setState(() => _i = v),
        backgroundColor: C.surface,
        indicatorColor: C.cyan.withOpacity(0.15),
        height: 68,
        labelTextStyle: WidgetStateProperty.all(ts(10.5, m: true, c: C.dim, ls: 1)),
        destinations: [
          dest(Icons.dashboard_outlined, 'HQ'),
          dest(Icons.checklist, 'MISSIONS'),
          dest(Icons.notifications_active_outlined, 'ALERTS'),
          dest(Icons.science_outlined, 'LAB'),
          dest(Icons.settings_outlined, 'SETUP'),
        ],
      ),
    );
  }
}
