import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/auth.dart';
import '../core/theme.dart';
import '../ui/widgets.dart';

class LockScreen extends StatefulWidget {
  final Future<void> Function(AuthResult) onResult;
  const LockScreen({super.key, required this.onResult});
  @override
  State<LockScreen> createState() => _LockScreenState();
}

class _LockScreenState extends State<LockScreen> with SingleTickerProviderStateMixin {
  late final AnimationController _scan =
      AnimationController(vsync: this, duration: const Duration(seconds: 4))..repeat();
  final _ctrl = TextEditingController();
  int _fails = 0;
  DateTime? _lockedUntil;
  Timer? _timer;
  bool _denied = false;
  bool _hide = true;

  @override
  void dispose() {
    _scan.dispose();
    _ctrl.dispose();
    _timer?.cancel();
    super.dispose();
  }

  int get _wait => _lockedUntil == null ? 0 : max(0, _lockedUntil!.difference(DateTime.now()).inSeconds + 1);

  void _submit() {
    if (_wait > 0) return;
    final r = AppState.instance.auth.verify(_ctrl.text);
    if (r == AuthResult.denied) {
      _fails++;
      _denied = true;
      _ctrl.clear();
      if (_fails % 5 == 0) {
        _lockedUntil = DateTime.now().add(Duration(seconds: 30 * (_fails ~/ 5)));
        _timer?.cancel();
        _timer = Timer.periodic(const Duration(seconds: 1), (t) {
          if (_wait <= 0) t.cancel();
          if (mounted) setState(() {});
        });
      }
      setState(() {});
    } else {
      _denied = false;
      widget.onResult(r);
    }
  }

  @override
  Widget build(BuildContext context) {
    final locked = _wait > 0;
    Widget field = TextField(
      controller: _ctrl,
      obscureText: _hide,
      enabled: !locked,
      autocorrect: false,
      enableSuggestions: false,
      textAlign: TextAlign.center,
      style: ts(18, m: true, ls: 3),
      onSubmitted: (_) => _submit(),
      decoration: deco('Enter password').copyWith(
        suffixIcon: IconButton(
          icon: Icon(_hide ? Icons.visibility_off : Icons.visibility, color: C.dim, size: 20),
          onPressed: () => setState(() => _hide = !_hide),
        ),
      ),
    );
    if (_fails > 0) {
      field = TweenAnimationBuilder<double>(
        key: ValueKey(_fails),
        tween: Tween(begin: 0, end: 1),
        duration: const Duration(milliseconds: 450),
        builder: (c, v, child) => Transform.translate(offset: Offset(sin(v * pi * 6) * 12 * (1 - v), 0), child: child),
        child: field,
      );
    }

    return Scaffold(
      body: Stack(children: [
        Positioned.fill(
          child: AnimatedBuilder(
            animation: _scan,
            builder: (c, _) => CustomPaint(painter: _HudPainter(_scan.value, _denied ? C.red : C.cyan)),
          ),
        ),
        SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 32),
              child: Column(mainAxisSize: MainAxisSize.min, children: [
                Container(
                  width: 104,
                  height: 104,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(color: (_denied ? C.red : C.cyan).withOpacity(0.6), width: 2),
                    boxShadow: [BoxShadow(color: (_denied ? C.red : C.cyan).withOpacity(0.35), blurRadius: 30)],
                  ),
                  child: Icon(_denied ? Icons.gpp_bad : Icons.fingerprint, size: 56, color: _denied ? C.red : C.cyan),
                ),
                const SizedBox(height: 28),
                Text('AGENT.OS', style: ts(30, m: true, w: FontWeight.w800, ls: 6)),
                const SizedBox(height: 6),
                Text('IDENTITY VERIFICATION', style: ts(12, m: true, c: C.dim, ls: 3)),
                const SizedBox(height: 36),
                field,
                const SizedBox(height: 14),
                SizedBox(
                  height: 20,
                  child: Text(
                    locked
                        ? 'LOCKDOWN - RETRY IN ${_wait}s'
                        : _denied
                            ? 'ACCESS DENIED'
                            : '',
                    style: ts(12, m: true, c: C.red, ls: 2, w: FontWeight.w700),
                  ),
                ),
                const SizedBox(height: 10),
                NeonButton('AUTHENTICATE', icon: Icons.lock_open, onTap: locked ? null : _submit),
              ]),
            ),
          ),
        ),
      ]),
    );
  }
}

class _HudPainter extends CustomPainter {
  final double t;
  final Color color;
  _HudPainter(this.t, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final grid = Paint()
      ..color = color.withOpacity(0.06)
      ..strokeWidth = 1;
    for (double x = 0; x < size.width; x += 32) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), grid);
    }
    for (double y = 0; y < size.height; y += 32) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), grid);
    }
    final y = size.height * t;
    final rect = Rect.fromLTWH(0, y - 60, size.width, 120);
    final scan = Paint()
      ..shader = LinearGradient(
        begin: Alignment.topCenter,
        end: Alignment.bottomCenter,
        colors: [color.withOpacity(0), color.withOpacity(0.14), color.withOpacity(0)],
      ).createShader(rect);
    canvas.drawRect(rect, scan);
    final corner = Paint()
      ..color = color.withOpacity(0.7)
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;
    const m = 18.0, l = 26.0;
    canvas.drawPath(
        Path()
          ..moveTo(m, m + l)
          ..lineTo(m, m)
          ..lineTo(m + l, m),
        corner);
    canvas.drawPath(
        Path()
          ..moveTo(size.width - m - l, m)
          ..lineTo(size.width - m, m)
          ..lineTo(size.width - m, m + l),
        corner);
    canvas.drawPath(
        Path()
          ..moveTo(m, size.height - m - l)
          ..lineTo(m, size.height - m)
          ..lineTo(m + l, size.height - m),
        corner);
    canvas.drawPath(
        Path()
          ..moveTo(size.width - m - l, size.height - m)
          ..lineTo(size.width - m, size.height - m)
          ..lineTo(size.width - m, size.height - m - l),
        corner);
  }

  @override
  bool shouldRepaint(_HudPainter old) => old.t != t || old.color != color;
}
