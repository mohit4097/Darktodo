import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/theme.dart';
import '../ui/widgets.dart';

class ExamPage extends StatelessWidget {
  const ExamPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: C.bg,
        title: Text('EXAMS', style: ts(18, m: true, w: FontWeight.w800, ls: 2)),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: C.red,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add),
        label: Text('ADD EXAM', style: ts(12, m: true, c: Colors.black, w: FontWeight.w800, ls: 1)),
        onPressed: () => showSheet(context, (_) => const _ExamForm()),
      ),
      body: ListenableBuilder(
        listenable: AppState.instance,
        builder: (context, _) {
          final ex = AppState.instance.exams;
          if (ex.isEmpty) {
            return const EmptyState(Icons.school_outlined, 'No exams added.\nYou get reminders 1 day and 1 hour before.');
          }
          return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 90), children: [
            for (final e in ex)
              Builder(builder: (context) {
                final left = e.at.difference(DateTime.now());
                final past = left.isNegative;
                final color = past ? C.dim : (left.inDays < 3 ? C.red : (left.inDays < 10 ? C.amber : C.green));
                return HudCard(
                  accent: color,
                  margin: const EdgeInsets.only(bottom: 12),
                  child: Row(children: [
                    Column(children: [
                      Text(past ? '-' : '${left.inDays}', style: ts(34, m: true, c: color, w: FontWeight.w800)),
                      Text(past ? 'DONE' : 'DAYS', style: ts(10, m: true, c: C.dim, ls: 1.5)),
                    ]),
                    const SizedBox(width: 18),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(e.subject, style: ts(16, w: FontWeight.w800)),
                        const SizedBox(height: 3),
                        Text(fmtDT(e.at), style: ts(11.5, m: true, c: C.dim)),
                        if (!past) Text('in ${countdown(e.at)}', style: ts(11.5, m: true, c: color)),
                      ]),
                    ),
                    IconButton(
                      icon: const Icon(Icons.delete_outline, color: C.dim),
                      onPressed: () => AppState.instance.deleteExam(e),
                    ),
                  ]),
                );
              }),
          ]);
        },
      ),
    );
  }
}

class _ExamForm extends StatefulWidget {
  const _ExamForm();
  @override
  State<_ExamForm> createState() => _ExamFormState();
}

class _ExamFormState extends State<_ExamForm> {
  final _subject = TextEditingController();
  DateTime _at = DateTime.now().add(const Duration(days: 7));

  @override
  void dispose() {
    _subject.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('NEW EXAM', style: ts(16, m: true, w: FontWeight.w800, ls: 2)),
      const SizedBox(height: 16),
      TextField(controller: _subject, style: ts(15), decoration: deco('Subject', icon: Icons.school)),
      const SizedBox(height: 12),
      DateTimeField(label: 'Exam date & time', value: _at, onChanged: (d) => setState(() => _at = d)),
      const SizedBox(height: 22),
      NeonButton('SAVE EXAM', icon: Icons.check, color: C.red, onTap: () async {
        final s = _subject.text.trim();
        if (s.isEmpty) {
          toast(context, 'Enter the subject');
          return;
        }
        await AppState.instance.addExam(s, _at);
        if (context.mounted) Navigator.pop(context);
      }),
    ]);
  }
}
