import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/auth.dart';
import '../core/theme.dart';
import '../ui/widgets.dart';
import 'lock_screen.dart';
import 'secret_home.dart';
import 'shell.dart';

/// Decides what to show: lock screen -> normal space or (later) secret space.
class RootGate extends StatefulWidget {
  const RootGate({super.key});
  @override
  State<RootGate> createState() => _RootGateState();
}

class _RootGateState extends State<RootGate> with WidgetsBindingObserver {
  AuthResult? _session;
  bool _booting = true;
  DateTime? _pausedAt;
  final _app = AppState.instance;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    _boot();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  Future<void> _boot() async {
    if (!_app.auth.hasLock) {
      await _app.openSpace('normal');
      _session = AuthResult.normal;
    }
    if (mounted) setState(() => _booting = false);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.paused) {
      _pausedAt = DateTime.now();
    } else if (state == AppLifecycleState.resumed && _session != null) {
      final away = _pausedAt == null ? Duration.zero : DateTime.now().difference(_pausedAt!);
      _pausedAt = null;
      if (_app.auth.hasLock && _app.autoLock && away.inSeconds > 15) {
        _lock();
      } else {
        _app.refresh();
      }
    }
  }

  void _lock() {
    _app.closeSpace();
    if (mounted) setState(() => _session = null);
  }

  Future<void> _unlocked(AuthResult r) async {
    await _app.openSpace(r == AuthResult.secret ? 'secret' : 'normal');
    if (mounted) setState(() => _session = r);
  }

  @override
  Widget build(BuildContext context) {
    if (_booting) {
      return Scaffold(
        body: Center(child: Text('AGENT.OS', style: ts(22, m: true, c: C.cyan, ls: 4, w: FontWeight.w800))),
      );
    }
    switch (_session) {
      case null:
      case AuthResult.denied:
        return LockScreen(onResult: _unlocked);
      case AuthResult.normal:
        return Shell(onLock: _lock);
      case AuthResult.secret:
        return SecretHome(onLock: _lock);
    }
  }
}
