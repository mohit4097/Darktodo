import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/theme.dart';
import '../ui/charts.dart';
import '../ui/widgets.dart';

const _cats = ['Food', 'Travel', 'Study', 'Fun', 'Bills', 'Other'];
const _catColors = [C.amber, C.cyan, C.violet, C.red, C.green, C.dim];
Color _catColor(String c) {
  final i = _cats.indexOf(c);
  return i < 0 ? C.dim : _catColors[i];
}

class ExpensePage extends StatelessWidget {
  const ExpensePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: C.bg,
        title: Text('EXPENSES', style: ts(18, m: true, w: FontWeight.w800, ls: 2)),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: C.green,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add),
        label: Text('ADD', style: ts(12, m: true, c: Colors.black, w: FontWeight.w800, ls: 1)),
        onPressed: () => showSheet(context, (_) => const _ExpenseForm()),
      ),
      body: ListenableBuilder(
        listenable: AppState.instance,
        builder: (context, _) {
          final s = AppState.instance;
          final by = s.monthByCategory;
          return ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 90), children: [
            HudCard(
              accent: C.green,
              child: Row(children: [
                Donut(
                  size: 130,
                  values: [for (final c in _cats) by[c] ?? 0],
                  colors: _catColors,
                  center: Column(mainAxisSize: MainAxisSize.min, children: [
                    Text('THIS MONTH', style: ts(8.5, m: true, c: C.dim, ls: 1)),
                    Text('₹${s.monthSpend.toStringAsFixed(0)}', style: ts(18, m: true, w: FontWeight.w800, c: C.green)),
                  ]),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(children: [
                    for (var i = 0; i < _cats.length; i++)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 3),
                        child: Row(children: [
                          Container(width: 9, height: 9, decoration: BoxDecoration(color: _catColors[i], shape: BoxShape.circle)),
                          const SizedBox(width: 8),
                          Expanded(child: Text(_cats[i], style: ts(12, c: C.dim))),
                          Text('₹${(by[_cats[i]] ?? 0).toStringAsFixed(0)}', style: ts(12, m: true)),
                        ]),
                      ),
                  ]),
                ),
              ]),
            ),
            const SectionHeader('Recent'),
            if (s.expenses.isEmpty)
              const EmptyState(Icons.account_balance_wallet_outlined, 'No expenses logged.')
            else
              for (final e in s.expenses.take(40))
                HudCard(
                  accent: _catColor(e.category),
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.fromLTRB(14, 8, 4, 8),
                  child: Row(children: [
                    Container(width: 4, height: 34, color: _catColor(e.category)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(e.note.isEmpty ? e.category : e.note, style: ts(14, w: FontWeight.w700)),
                        Text('${e.category} • ${fmtDT(e.at)}', style: ts(10.5, m: true, c: C.dim)),
                      ]),
                    ),
                    Text('₹${e.amount.toStringAsFixed(0)}', style: ts(15, m: true, w: FontWeight.w800)),
                    IconButton(
                      icon: const Icon(Icons.close, size: 18, color: C.dim),
                      onPressed: () => s.deleteExpense(e),
                    ),
                  ]),
                ),
          ]);
        },
      ),
    );
  }
}

class _ExpenseForm extends StatefulWidget {
  const _ExpenseForm();
  @override
  State<_ExpenseForm> createState() => _ExpenseFormState();
}

class _ExpenseFormState extends State<_ExpenseForm> {
  final _amount = TextEditingController();
  final _note = TextEditingController();
  String _cat = 'Food';

  @override
  void dispose() {
    _amount.dispose();
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('NEW EXPENSE', style: ts(16, m: true, w: FontWeight.w800, ls: 2)),
      const SizedBox(height: 16),
      TextField(
        controller: _amount,
        keyboardType: const TextInputType.numberWithOptions(decimal: true),
        style: ts(18, m: true),
        decoration: deco('Amount (₹)', icon: Icons.currency_rupee),
      ),
      const SizedBox(height: 12),
      TextField(controller: _note, style: ts(14), decoration: deco('Note (optional)', icon: Icons.notes)),
      const SizedBox(height: 14),
      ChipRow<String>(
        values: _cats,
        selected: _cat,
        color: _catColor(_cat),
        label: (v) => v,
        onChanged: (v) => setState(() => _cat = v),
      ),
      const SizedBox(height: 22),
      NeonButton('SAVE', icon: Icons.check, color: C.green, onTap: () async {
        final a = double.tryParse(_amount.text.trim());
        if (a == null || a <= 0) {
          toast(context, 'Enter a valid amount');
          return;
        }
        await AppState.instance.addExpense(a, _cat, _note.text.trim());
        if (context.mounted) Navigator.pop(context);
      }),
    ]);
  }
}
