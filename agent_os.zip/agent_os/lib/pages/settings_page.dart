import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/auth.dart';
import '../core/notification_service.dart';
import '../core/theme.dart';
import '../ui/widgets.dart';

class SettingsPage extends StatelessWidget {
  final VoidCallback onLock;
  const SettingsPage({super.key, required this.onLock});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: C.bg,
        title: Text('SETUP', style: ts(18, m: true, w: FontWeight.w800, ls: 2)),
      ),
      body: ListenableBuilder(
        listenable: AppState.instance,
        builder: (context, _) {
          final s = AppState.instance;
          final hasLock = s.auth.hasLock;
          return ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 32), children: [
            const SectionHeader('Security'),
            HudCard(
              child: Column(children: [
                _row(
                  icon: hasLock ? Icons.lock : Icons.lock_open,
                  color: hasLock ? C.green : C.dim,
                  title: 'App password',
                  sub: hasLock ? 'Enabled - asked every time you open the app' : 'Off - the app opens directly',
                  trailing: TextButton(
                    onPressed: () => showSheet(context, (_) => _PasswordForm(change: hasLock)),
                    child: Text(hasLock ? 'CHANGE' : 'SET', style: ts(12, m: true, c: C.cyan, w: FontWeight.w800)),
                  ),
                ),
                if (hasLock) ...[
                  const Divider(color: C.line, height: 20),
                  _row(
                    icon: Icons.timer_off,
                    color: C.amber,
                    title: 'Auto-lock',
                    sub: 'Lock after leaving the app for 15 sec',
                    trailing: Switch(value: s.autoLock, onChanged: (v) => s.setAutoLock(v)),
                  ),
                  const Divider(color: C.line, height: 20),
                  _row(
                    icon: Icons.lock_reset,
                    color: C.red,
                    title: 'Remove password',
                    sub: 'Needs your current password',
                    trailing: TextButton(
                      onPressed: () => _removeDialog(context),
                      child: Text('REMOVE', style: ts(12, m: true, c: C.red, w: FontWeight.w800)),
                    ),
                  ),
                  const Divider(color: C.line, height: 20),
                  _row(
                    icon: Icons.logout,
                    color: C.cyan,
                    title: 'Lock now',
                    sub: 'Return to the lock screen',
                    trailing: TextButton(
                      onPressed: onLock,
                      child: Text('LOCK', style: ts(12, m: true, c: C.cyan, w: FontWeight.w800)),
                    ),
                  ),
                ],
              ]),
            ),
            const SectionHeader('Notifications'),
            HudCard(
              child: Column(children: [
                _row(
                  icon: Icons.notifications_active,
                  color: C.cyan,
                  title: 'Allow notifications',
                  sub: 'Required for reminders',
                  trailing: TextButton(
                    onPressed: () async {
                      final ok = await NotificationService.instance.requestPermission();
                      if (context.mounted) toast(context, ok ? 'Notifications allowed' : 'Permission not granted');
                    },
                    child: Text('ALLOW', style: ts(12, m: true, c: C.cyan, w: FontWeight.w800)),
                  ),
                ),
                const Divider(color: C.line, height: 20),
                _row(
                  icon: Icons.alarm_on,
                  color: C.amber,
                  title: 'Exact alarms',
                  sub: 'Makes reminders fire on the exact minute',
                  trailing: TextButton(
                    onPressed: () => NotificationService.instance.requestExactAlarms(),
                    child: Text('ENABLE', style: ts(12, m: true, c: C.amber, w: FontWeight.w800)),
                  ),
                ),
                const Divider(color: C.line, height: 20),
                _row(
                  icon: Icons.send,
                  color: C.green,
                  title: 'Send test alert',
                  sub: 'Checks that notifications work',
                  trailing: TextButton(
                    onPressed: () => NotificationService.instance
                        .showNow('✅ AGENT.OS online', 'Notifications are working.'),
                    child: Text('TEST', style: ts(12, m: true, c: C.green, w: FontWeight.w800)),
                  ),
                ),
              ]),
            ),
            const SectionHeader('Vault'),
            HudCard(
              accent: C.red,
              child: _row(
                icon: Icons.shield,
                color: C.red,
                title: 'Sector 7',
                sub: 'Reserved - coming in a future update',
                trailing: const Icon(Icons.lock_outline, color: C.dim, size: 20),
              ),
            ),
            const SectionHeader('Data'),
            HudCard(
              child: Column(children: [
                _row(
                  icon: Icons.history,
                  color: C.dim,
                  title: 'Clear notification history',
                  sub: '${s.notifs.where((n) => n.status != 'pending').length} entries',
                  trailing: TextButton(
                    onPressed: () => s.clearNotifHistory(),
                    child: Text('CLEAR', style: ts(12, m: true, c: C.dim, w: FontWeight.w800)),
                  ),
                ),
                const Divider(color: C.line, height: 20),
                _row(
                  icon: Icons.checklist,
                  color: C.dim,
                  title: 'Clear mission history',
                  sub: '${s.tasks.where((t) => t.status != 'active').length} entries',
                  trailing: TextButton(
                    onPressed: () => s.clearTaskHistory(),
                    child: Text('CLEAR', style: ts(12, m: true, c: C.dim, w: FontWeight.w800)),
                  ),
                ),
              ]),
            ),
            const SizedBox(height: 24),
            Center(child: Text('AGENT.OS  v1.0', style: ts(11, m: true, c: C.dim, ls: 2))),
          ]);
        },
      ),
    );
  }

  Widget _row({
    required IconData icon,
    required Color color,
    required String title,
    required String sub,
    required Widget trailing,
  }) =>
      Row(children: [
        Icon(icon, color: color, size: 22),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: ts(14.5, w: FontWeight.w700)),
            Text(sub, style: ts(11.5, c: C.dim)),
          ]),
        ),
        trailing,
      ]);

  void _removeDialog(BuildContext context) {
    final ctrl = TextEditingController();
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: C.surface,
        title: Text('REMOVE PASSWORD', style: ts(15, m: true, w: FontWeight.w800, ls: 1.5)),
        content: TextField(
          controller: ctrl,
          obscureText: true,
          style: ts(15, m: true),
          decoration: deco('Current password'),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: Text('CANCEL', style: ts(12, m: true, c: C.dim))),
          TextButton(
            onPressed: () async {
              final app = AppState.instance;
              if (app.auth.verifyNormal(ctrl.text)) {
                await app.auth.removeNormal();
                app.refreshUi();
                if (ctx.mounted) Navigator.pop(ctx);
                if (context.mounted) toast(context, 'Password removed');
              } else {
                toast(ctx, 'Wrong password');
              }
            },
            child: Text('REMOVE', style: ts(12, m: true, c: C.red, w: FontWeight.w800)),
          ),
        ],
      ),
    ).then((_) => ctrl.dispose());
  }
}

class _PasswordForm extends StatefulWidget {
  final bool change;
  const _PasswordForm({required this.change});
  @override
  State<_PasswordForm> createState() => _PasswordFormState();
}

class _PasswordFormState extends State<_PasswordForm> {
  final _old = TextEditingController();
  final _a = TextEditingController();
  final _b = TextEditingController();

  @override
  void dispose() {
    _old.dispose();
    _a.dispose();
    _b.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text(widget.change ? 'CHANGE PASSWORD' : 'SET PASSWORD', style: ts(16, m: true, w: FontWeight.w800, ls: 2)),
      const SizedBox(height: 16),
      if (widget.change) ...[
        TextField(controller: _old, obscureText: true, style: ts(15, m: true), decoration: deco('Current password', icon: Icons.key)),
        const SizedBox(height: 12),
      ],
      TextField(controller: _a, obscureText: true, style: ts(15, m: true), decoration: deco('New password (min 4)', icon: Icons.lock)),
      const SizedBox(height: 12),
      TextField(controller: _b, obscureText: true, style: ts(15, m: true), decoration: deco('Repeat password', icon: Icons.lock_outline)),
      const SizedBox(height: 22),
      NeonButton('SAVE', icon: Icons.check, onTap: () async {
        final app = AppState.instance;
        if (widget.change && !app.auth.verifyNormal(_old.text)) {
          toast(context, 'Current password is wrong');
          return;
        }
        if (_a.text.length < 4) {
          toast(context, 'Use at least 4 characters');
          return;
        }
        if (_a.text != _b.text) {
          toast(context, 'Passwords do not match');
          return;
        }
        if (app.auth.hasSecret && app.auth.verify(_a.text) == AuthResult.secret) {
          toast(context, 'Choose a different password');
          return;
        }
        await app.auth.setNormal(_a.text);
        app.refreshUi();
        if (context.mounted) {
          Navigator.pop(context);
          toast(context, 'Password saved');
        }
      }),
    ]);
  }
}
