import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../ui/widgets.dart';

class HabitsPage extends StatelessWidget {
  const HabitsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: C.bg,
        title: Text('HABITS', style: ts(18, m: true, w: FontWeight.w800, ls: 2)),
      ),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: C.amber,
        foregroundColor: Colors.black,
        icon: const Icon(Icons.add),
        label: Text('NEW HABIT', style: ts(12, m: true, c: Colors.black, w: FontWeight.w800, ls: 1)),
        onPressed: () => showSheet(context, (_) => const _HabitForm()),
      ),
      body: ListenableBuilder(
        listenable: AppState.instance,
        builder: (context, _) {
          final hs = AppState.instance.habits;
          if (hs.isEmpty) return const EmptyState(Icons.loop, 'No habits yet.\nBuild streaks with daily check-ins.');
          return ListView(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 90),
            children: [for (final h in hs) _HabitCard(h)],
          );
        },
      ),
    );
  }
}

class _HabitCard extends StatelessWidget {
  final Habit h;
  const _HabitCard(this.h);

  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final days = List.generate(7, (i) => DateTime(now.year, now.month, now.day - (6 - i)));
    const wk = ['M', 'T', 'W', 'T', 'F', 'S', 'S'];
    return HudCard(
      accent: C.amber,
      margin: const EdgeInsets.only(bottom: 12),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Row(children: [
          Text(h.emoji, style: const TextStyle(fontSize: 26)),
          const SizedBox(width: 12),
          Expanded(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(h.name, style: ts(16, w: FontWeight.w800)),
              Text(
                h.remindMin == null ? 'No reminder' : 'Daily at ${fmtTimeOfDay(h.remindMin!)}',
                style: ts(11.5, m: true, c: C.dim),
              ),
            ]),
          ),
          Column(children: [
            Row(children: [
              const Icon(Icons.local_fire_department, color: C.amber, size: 20),
              Text('${h.streak}', style: ts(20, m: true, c: C.amber, w: FontWeight.w800)),
            ]),
            Text('STREAK', style: ts(9, m: true, c: C.dim, ls: 1)),
          ]),
          IconButton(
            icon: const Icon(Icons.delete_outline, color: C.dim, size: 20),
            onPressed: () => AppState.instance.deleteHabit(h),
          ),
        ]),
        const SizedBox(height: 14),
        Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
          for (final d in days)
            GestureDetector(
              onTap: () => AppState.instance.toggleHabit(h, d),
              child: Column(children: [
                Text(wk[d.weekday - 1], style: ts(10.5, m: true, c: C.dim)),
                const SizedBox(height: 6),
                AnimatedContainer(
                  duration: const Duration(milliseconds: 200),
                  width: 36,
                  height: 36,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: h.done.contains(dayKey(d)) ? C.amber : Colors.transparent,
                    border: Border.all(
                      color: dayKey(d) == dayKey(now) ? C.amber : C.line,
                      width: dayKey(d) == dayKey(now) ? 2 : 1,
                    ),
                  ),
                  child: h.done.contains(dayKey(d))
                      ? const Icon(Icons.check, color: Colors.black, size: 20)
                      : Center(child: Text('${d.day}', style: ts(11, m: true, c: C.dim))),
                ),
              ]),
            ),
        ]),
      ]),
    );
  }
}

class _HabitForm extends StatefulWidget {
  const _HabitForm();
  @override
  State<_HabitForm> createState() => _HabitFormState();
}

class _HabitFormState extends State<_HabitForm> {
  final _name = TextEditingController();
  String _emoji = '🎯';
  TimeOfDay? _time;

  static const _emojis = ['🎯', '💧', '📚', '🏃', '🧘', '😴', '🍎', '✍️'];

  @override
  void dispose() {
    _name.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('NEW HABIT', style: ts(16, m: true, w: FontWeight.w800, ls: 2)),
      const SizedBox(height: 16),
      TextField(controller: _name, style: ts(15), decoration: deco('Habit name', icon: Icons.loop)),
      const SizedBox(height: 14),
      ChipRow<String>(
        values: _emojis,
        selected: _emoji,
        color: C.amber,
        label: (v) => v,
        onChanged: (v) => setState(() => _emoji = v),
      ),
      const SizedBox(height: 14),
      InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: () async {
          final t = await showTimePicker(context: context, initialTime: _time ?? const TimeOfDay(hour: 20, minute: 0));
          if (t != null) setState(() => _time = t);
        },
        child: InputDecorator(
          decoration: deco('Daily reminder', icon: Icons.alarm).copyWith(
            suffixIcon: _time == null
                ? null
                : IconButton(icon: const Icon(Icons.clear, size: 18), onPressed: () => setState(() => _time = null)),
          ),
          child: Text(_time == null ? 'Off' : _time!.format(context), style: ts(14, m: true)),
        ),
      ),
      const SizedBox(height: 22),
      NeonButton('ADD HABIT', icon: Icons.check, color: C.amber, onTap: () async {
        final name = _name.text.trim();
        if (name.isEmpty) {
          toast(context, 'Name the habit');
          return;
        }
        await AppState.instance.addHabit(name, _emoji, _time == null ? null : _time!.hour * 60 + _time!.minute);
        if (context.mounted) Navigator.pop(context);
      }),
    ]);
  }
}
