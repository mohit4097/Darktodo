import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../ui/widgets.dart';

/// Placeholder for the future secret system (built after exams).
/// The auth flow, separate storage space and routing are already wired:
/// entering the secret password lands here instead of the normal Shell.
class SecretHome extends StatelessWidget {
  final VoidCallback onLock;
  const SecretHome({super.key, required this.onLock});

  @override
  Widget build(BuildContext context) => Scaffold(
        body: SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
              const Icon(Icons.shield, size: 64, color: C.red),
              const SizedBox(height: 16),
              Text('SECTOR 7', style: ts(26, m: true, c: C.red, w: FontWeight.w800, ls: 4)),
              const SizedBox(height: 8),
              Text('Secure vault - under construction', style: ts(13, c: C.dim, m: true)),
              const SizedBox(height: 32),
              NeonButton('LOCK', icon: Icons.lock, onTap: onLock, color: C.red),
            ]),
          ),
        ),
      );
}
