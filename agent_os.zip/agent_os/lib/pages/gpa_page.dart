import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../ui/widgets.dart';

class _Row {
  final TextEditingController name = TextEditingController();
  double credits = 3;
  double grade = 8;
}

/// Quick SGPA calculator (10-point scale). Not saved - just a handy tool.
class GpaPage extends StatefulWidget {
  const GpaPage({super.key});
  @override
  State<GpaPage> createState() => _GpaPageState();
}

class _GpaPageState extends State<GpaPage> {
  final List<_Row> _rows = [_Row(), _Row(), _Row()];

  static const _grades = <String, double>{'O': 10, 'A+': 9, 'A': 8, 'B+': 7, 'B': 6, 'C': 5, 'F': 0};

  @override
  void dispose() {
    for (final r in _rows) {
      r.name.dispose();
    }
    super.dispose();
  }

  double get _sgpa {
    final cr = _rows.fold<double>(0, (a, r) => a + r.credits);
    if (cr == 0) return 0;
    return _rows.fold<double>(0, (a, r) => a + r.credits * r.grade) / cr;
  }

  @override
  Widget build(BuildContext context) {
    final g = _sgpa;
    final color = g >= 8.5 ? C.green : (g >= 7 ? C.cyan : (g >= 5 ? C.amber : C.red));
    return Scaffold(
      appBar: AppBar(
        backgroundColor: C.bg,
        title: Text('GPA CALCULATOR', style: ts(18, m: true, w: FontWeight.w800, ls: 2)),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: C.cyan,
        foregroundColor: Colors.black,
        onPressed: () => setState(() => _rows.add(_Row())),
        child: const Icon(Icons.add),
      ),
      body: ListView(padding: const EdgeInsets.fromLTRB(16, 8, 16, 90), children: [
        HudCard(
          accent: color,
          child: Column(children: [
            Text('SGPA', style: ts(12, m: true, c: C.dim, ls: 3)),
            const SizedBox(height: 6),
            Text(g.toStringAsFixed(2), style: ts(54, m: true, c: color, w: FontWeight.w800)),
            Text('${_rows.fold<double>(0, (a, r) => a + r.credits).toStringAsFixed(0)} credits',
                style: ts(12, m: true, c: C.dim)),
          ]),
        ),
        const SectionHeader('Subjects'),
        for (var i = 0; i < _rows.length; i++)
          HudCard(
            margin: const EdgeInsets.only(bottom: 10),
            padding: const EdgeInsets.fromLTRB(12, 10, 4, 10),
            child: Row(children: [
              Expanded(
                flex: 3,
                child: TextField(
                  controller: _rows[i].name,
                  style: ts(14),
                  decoration: deco('Subject ${i + 1}'),
                ),
              ),
              const SizedBox(width: 8),
              _drop<double>(
                value: _rows[i].credits,
                items: const [1, 2, 3, 4, 5, 6],
                label: (v) => '${v.toInt()} cr',
                onChanged: (v) => setState(() => _rows[i].credits = v),
              ),
              const SizedBox(width: 6),
              _drop<double>(
                value: _rows[i].grade,
                items: _grades.values.toList(),
                label: (v) => _grades.entries.firstWhere((e) => e.value == v).key,
                onChanged: (v) => setState(() => _rows[i].grade = v),
              ),
              IconButton(
                icon: const Icon(Icons.close, size: 18, color: C.dim),
                onPressed: _rows.length > 1
                    ? () => setState(() {
                          _rows[i].name.dispose();
                          _rows.removeAt(i);
                        })
                    : null,
              ),
            ]),
          ),
      ]),
    );
  }

  Widget _drop<T>({
    required T value,
    required List<T> items,
    required String Function(T) label,
    required ValueChanged<T> onChanged,
  }) =>
      DropdownButton<T>(
        value: value,
        dropdownColor: C.surface2,
        underline: const SizedBox.shrink(),
        style: ts(13, m: true, c: C.cyan, w: FontWeight.w700),
        items: [for (final v in items) DropdownMenuItem<T>(value: v, child: Text(label(v)))],
        onChanged: (v) {
          if (v != null) onChanged(v);
        },
      );
}
