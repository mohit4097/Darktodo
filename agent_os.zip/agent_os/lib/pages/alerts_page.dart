import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../ui/widgets.dart';

IconData _srcIcon(String s) {
  switch (s) {
    case 'task':
      return Icons.flag;
    case 'habit':
      return Icons.loop;
    case 'exam':
      return Icons.school;
    default:
      return Icons.notifications;
  }
}

class AlertsPage extends StatelessWidget {
  const AlertsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: C.bg,
          title: Text('ALERTS', style: ts(18, m: true, w: FontWeight.w800, ls: 2)),
          bottom: TabBar(
            indicatorColor: C.cyan,
            labelColor: C.cyan,
            unselectedLabelColor: C.dim,
            labelStyle: ts(12, m: true, ls: 2, w: FontWeight.w800),
            tabs: const [Tab(text: 'UPCOMING'), Tab(text: 'HISTORY')],
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: C.cyan,
          foregroundColor: Colors.black,
          icon: const Icon(Icons.add_alert),
          label: Text('NEW ALERT', style: ts(12, m: true, c: Colors.black, w: FontWeight.w800, ls: 1)),
          onPressed: () => showSheet(context, (_) => const _AlertForm()),
        ),
        body: ListenableBuilder(
          listenable: AppState.instance,
          builder: (context, _) {
            final s = AppState.instance;
            final up = s.upcoming();
            final hist = s.notifs.where((n) => n.status != 'pending').toList()
              ..sort((a, b) => b.at.compareTo(a.at));
            return TabBarView(children: [
              up.isEmpty
                  ? const EmptyState(Icons.notifications_none, 'No upcoming alerts.\nTap NEW ALERT to schedule one.')
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 90),
                      children: [
                        for (final u in up)
                          HudCard(
                            margin: const EdgeInsets.only(bottom: 10),
                            padding: const EdgeInsets.fromLTRB(14, 12, 6, 12),
                            child: Row(children: [
                              Icon(_srcIcon(u.source), color: C.cyan),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(u.title, style: ts(14.5, w: FontWeight.w700)),
                                  Text(fmtDT(u.at), style: ts(11.5, m: true, c: C.dim)),
                                ]),
                              ),
                              Text(countdown(u.at), style: ts(13, m: true, c: C.cyan, w: FontWeight.w700)),
                              if (u.notifId != null)
                                IconButton(
                                  icon: const Icon(Icons.close, color: C.dim, size: 20),
                                  onPressed: () => s.cancelNotif(u.notifId!),
                                )
                              else
                                const SizedBox(width: 12),
                            ]),
                          ),
                      ],
                    ),
              hist.isEmpty
                  ? const EmptyState(Icons.history, 'Notification history is empty.\nDelivered alerts show up here.')
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 90),
                      children: [
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton.icon(
                            onPressed: () => s.clearNotifHistory(),
                            icon: const Icon(Icons.delete_sweep, size: 18, color: C.dim),
                            label: Text('CLEAR ALL', style: ts(11, m: true, c: C.dim, ls: 1)),
                          ),
                        ),
                        for (final n in hist) _HistTile(n),
                      ],
                    ),
            ]);
          },
        ),
      ),
    );
  }
}

class _HistTile extends StatelessWidget {
  final NotifItem n;
  const _HistTile(this.n);

  @override
  Widget build(BuildContext context) {
    final cancelled = n.status == 'cancelled';
    final color = cancelled ? C.red : C.green;
    return HudCard(
      accent: color,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(14, 10, 4, 10),
      child: Row(children: [
        Icon(cancelled ? Icons.notifications_off : _srcIcon(n.source), color: color, size: 22),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(n.title, style: ts(14.5, w: FontWeight.w700)),
            if (n.body.isNotEmpty) Text(n.body, maxLines: 1, overflow: TextOverflow.ellipsis, style: ts(12, c: C.dim)),
            const SizedBox(height: 3),
            Text(
              '${cancelled ? 'CANCELLED' : 'DELIVERED'} • ${fmtDT(n.at)}',
              style: ts(10.5, m: true, c: color),
            ),
          ]),
        ),
        IconButton(
          icon: const Icon(Icons.delete_outline, color: C.dim, size: 20),
          onPressed: () => AppState.instance.removeNotif(n),
        ),
      ]),
    );
  }
}

class _AlertForm extends StatefulWidget {
  const _AlertForm();
  @override
  State<_AlertForm> createState() => _AlertFormState();
}

class _AlertFormState extends State<_AlertForm> {
  final _title = TextEditingController();
  final _body = TextEditingController();
  DateTime _at = DateTime.now().add(const Duration(minutes: 5));

  @override
  void dispose() {
    _title.dispose();
    _body.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('NEW ALERT', style: ts(16, m: true, w: FontWeight.w800, ls: 2)),
      const SizedBox(height: 16),
      TextField(controller: _title, style: ts(15), decoration: deco('Title', icon: Icons.title)),
      const SizedBox(height: 12),
      TextField(controller: _body, style: ts(14), decoration: deco('Message (optional)', icon: Icons.notes)),
      const SizedBox(height: 12),
      DateTimeField(label: 'Date & time', value: _at, onChanged: (d) => setState(() => _at = d)),
      const SizedBox(height: 22),
      NeonButton('SCHEDULE', icon: Icons.alarm_add, onTap: () async {
        final title = _title.text.trim();
        if (title.isEmpty) {
          toast(context, 'Give the alert a title');
          return;
        }
        if (!_at.isAfter(DateTime.now())) {
          toast(context, 'Pick a time in the future');
          return;
        }
        await AppState.instance.addNotif(title, _body.text.trim(), _at);
        if (context.mounted) Navigator.pop(context);
      }),
    ]);
  }
}
