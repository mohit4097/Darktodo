import 'package:flutter/material.dart';
import '../core/theme.dart';
import '../ui/widgets.dart';
import 'exam_page.dart';
import 'expense_page.dart';
import 'gpa_page.dart';
import 'habits_page.dart';
import 'study_page.dart';

class LabPage extends StatelessWidget {
  const LabPage({super.key});

  @override
  Widget build(BuildContext context) {
    final items = <_Tool>[
      _Tool('Habits', 'Streaks & daily check-ins', Icons.loop, C.amber, const HabitsPage()),
      _Tool('Focus Timer', 'Study sessions & stats', Icons.timer, C.violet, const StudyPage()),
      _Tool('Exams', 'Countdown & reminders', Icons.school, C.red, const ExamPage()),
      _Tool('Expenses', 'Spending & charts', Icons.account_balance_wallet, C.green, const ExpensePage()),
      _Tool('GPA Calc', 'SGPA in seconds', Icons.calculate, C.cyan, const GpaPage()),
    ];
    return Scaffold(
      appBar: AppBar(
        backgroundColor: C.bg,
        title: Text('LAB', style: ts(18, m: true, w: FontWeight.w800, ls: 2)),
      ),
      body: GridView.count(
        crossAxisCount: 2,
        padding: const EdgeInsets.all(16),
        mainAxisSpacing: 12,
        crossAxisSpacing: 12,
        childAspectRatio: 0.95,
        children: [
          for (final t in items)
            HudCard(
              accent: t.color,
              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => t.page)),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(color: t.color.withOpacity(0.14), borderRadius: BorderRadius.circular(12)),
                  child: Icon(t.icon, color: t.color, size: 26),
                ),
                const Spacer(),
                Text(t.title, style: ts(16, w: FontWeight.w800)),
                const SizedBox(height: 4),
                Text(t.sub, style: ts(11.5, c: C.dim)),
              ]),
            ),
        ],
      ),
    );
  }
}

class _Tool {
  final String title, sub;
  final IconData icon;
  final Color color;
  final Widget page;
  _Tool(this.title, this.sub, this.icon, this.color, this.page);
}
