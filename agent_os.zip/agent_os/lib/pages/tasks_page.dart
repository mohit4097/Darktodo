import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/models.dart';
import '../core/theme.dart';
import '../ui/widgets.dart';

Color _prio(int p) => p == 2 ? C.red : (p == 1 ? C.amber : C.green);

class TasksPage extends StatelessWidget {
  const TasksPage({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: C.bg,
          title: Text('MISSIONS', style: ts(18, m: true, w: FontWeight.w800, ls: 2)),
          bottom: TabBar(
            indicatorColor: C.cyan,
            labelColor: C.cyan,
            unselectedLabelColor: C.dim,
            labelStyle: ts(12, m: true, ls: 2, w: FontWeight.w800),
            tabs: const [Tab(text: 'ACTIVE'), Tab(text: 'HISTORY')],
          ),
        ),
        floatingActionButton: FloatingActionButton.extended(
          backgroundColor: C.cyan,
          foregroundColor: Colors.black,
          icon: const Icon(Icons.add),
          label: Text('NEW MISSION', style: ts(12, m: true, c: Colors.black, w: FontWeight.w800, ls: 1)),
          onPressed: () => showSheet(context, (_) => const _TaskForm()),
        ),
        body: ListenableBuilder(
          listenable: AppState.instance,
          builder: (context, _) {
            final s = AppState.instance;
            final active = s.tasks.where((t) => t.status == 'active').toList()
              ..sort((a, b) => a.due.compareTo(b.due));
            final hist = s.tasks.where((t) => t.status != 'active').toList()
              ..sort((a, b) => (b.completedAt ?? b.created).compareTo(a.completedAt ?? a.created));
            return TabBarView(children: [
              active.isEmpty
                  ? const EmptyState(Icons.flag_outlined, 'No active missions.\nTap NEW MISSION to deploy one.')
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 90),
                      children: [for (final t in active) _ActiveTile(t)],
                    ),
              hist.isEmpty
                  ? const EmptyState(Icons.history, 'Mission history is empty.')
                  : ListView(
                      padding: const EdgeInsets.fromLTRB(16, 12, 16, 90),
                      children: [
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton.icon(
                            onPressed: () => s.clearTaskHistory(),
                            icon: const Icon(Icons.delete_sweep, size: 18, color: C.dim),
                            label: Text('CLEAR ALL', style: ts(11, m: true, c: C.dim, ls: 1)),
                          ),
                        ),
                        for (final t in hist) _HistoryTile(t),
                      ],
                    ),
            ]);
          },
        ),
      ),
    );
  }
}

class _ActiveTile extends StatelessWidget {
  final Task t;
  const _ActiveTile(this.t);

  @override
  Widget build(BuildContext context) {
    final overdue = t.due.isBefore(DateTime.now());
    final color = _prio(t.priority);
    return HudCard(
      accent: color,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(8, 10, 4, 10),
      child: Row(children: [
        IconButton(
          icon: Icon(Icons.radio_button_unchecked, color: color, size: 28),
          onPressed: () {
            AppState.instance.completeTask(t);
            toast(context, 'Mission complete: ${t.title}');
          },
        ),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t.title, style: ts(15.5, w: FontWeight.w700)),
            if (t.note.isNotEmpty) Text(t.note, maxLines: 2, overflow: TextOverflow.ellipsis, style: ts(12.5, c: C.dim)),
            const SizedBox(height: 6),
            Wrap(spacing: 10, runSpacing: 4, crossAxisAlignment: WrapCrossAlignment.center, children: [
              Row(mainAxisSize: MainAxisSize.min, children: [
                Icon(Icons.schedule, size: 13, color: overdue ? C.red : C.dim),
                const SizedBox(width: 4),
                Text(fmtDT(t.due), style: ts(11.5, m: true, c: overdue ? C.red : C.dim)),
              ]),
              if (t.repeatMin > 0)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: C.cyan.withOpacity(0.12),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(repeatLabel(t.repeatMin), style: ts(10.5, m: true, c: C.cyan, w: FontWeight.w700)),
                ),
            ]),
          ]),
        ),
        IconButton(
          icon: const Icon(Icons.close, color: C.dim, size: 20),
          onPressed: () => AppState.instance.deleteTask(t),
        ),
      ]),
    );
  }
}

class _HistoryTile extends StatelessWidget {
  final Task t;
  const _HistoryTile(this.t);

  @override
  Widget build(BuildContext context) {
    final done = t.status == 'done';
    return HudCard(
      accent: done ? C.green : C.red,
      margin: const EdgeInsets.only(bottom: 10),
      padding: const EdgeInsets.fromLTRB(14, 10, 4, 10),
      child: Row(children: [
        Icon(done ? Icons.check_circle : Icons.cancel, color: done ? C.green : C.red),
        const SizedBox(width: 12),
        Expanded(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(t.title,
                style: ts(14.5, w: FontWeight.w700, c: C.dim).copyWith(decoration: TextDecoration.lineThrough)),
            const SizedBox(height: 4),
            Text(
              '${done ? 'COMPLETED' : 'DELETED'} ${t.completedAt == null ? '' : fmtDT(t.completedAt!)}',
              style: ts(10.5, m: true, c: done ? C.green : C.red, ls: 0.5),
            ),
            Text('${repeatLabel(t.repeatMin)} • due ${fmtDT(t.due)}', style: ts(10.5, m: true, c: C.dim)),
          ]),
        ),
        IconButton(
          icon: const Icon(Icons.delete_outline, color: C.dim, size: 20),
          onPressed: () => AppState.instance.purgeTask(t),
        ),
      ]),
    );
  }
}

class _TaskForm extends StatefulWidget {
  const _TaskForm();
  @override
  State<_TaskForm> createState() => _TaskFormState();
}

class _TaskFormState extends State<_TaskForm> {
  final _title = TextEditingController();
  final _note = TextEditingController();
  DateTime _due = DateTime.now().add(const Duration(minutes: 30));
  int _repeat = 0;
  int _priority = 1;

  static const _repeats = [0, 30, 60, 120, 360, 1440];

  @override
  void dispose() {
    _title.dispose();
    _note.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      Text('NEW MISSION', style: ts(16, m: true, w: FontWeight.w800, ls: 2)),
      const SizedBox(height: 16),
      TextField(controller: _title, style: ts(15), decoration: deco('Title', icon: Icons.flag)),
      const SizedBox(height: 12),
      TextField(controller: _note, style: ts(14), decoration: deco('Note (optional)', icon: Icons.notes)),
      const SizedBox(height: 12),
      DateTimeField(label: 'Remind me at', value: _due, onChanged: (d) => setState(() => _due = d)),
      const SizedBox(height: 16),
      Text('REMIND AGAIN', style: ts(11, m: true, c: C.dim, ls: 2)),
      const SizedBox(height: 8),
      ChipRow<int>(
        values: _repeats,
        selected: _repeat,
        label: (v) => v == 0 ? 'No repeat' : repeatLabel(v),
        onChanged: (v) => setState(() => _repeat = v),
      ),
      if (_repeat > 0)
        Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Text('Keeps reminding until you mark the mission complete.', style: ts(11.5, c: C.dim)),
        ),
      const SizedBox(height: 16),
      Text('PRIORITY', style: ts(11, m: true, c: C.dim, ls: 2)),
      const SizedBox(height: 8),
      ChipRow<int>(
        values: const [0, 1, 2],
        selected: _priority,
        color: _prio(_priority),
        label: (v) => const ['Low', 'Medium', 'High'][v],
        onChanged: (v) => setState(() => _priority = v),
      ),
      const SizedBox(height: 22),
      NeonButton('DEPLOY', icon: Icons.rocket_launch, onTap: () async {
        final title = _title.text.trim();
        if (title.isEmpty) {
          toast(context, 'Give the mission a title');
          return;
        }
        await AppState.instance.addTask(
          title: title,
          note: _note.text.trim(),
          due: _due,
          repeatMin: _repeat,
          priority: _priority,
        );
        if (context.mounted) Navigator.pop(context);
      }),
    ]);
  }
}
