import 'dart:async';
import 'package:flutter/material.dart';
import '../core/app_state.dart';
import '../core/notification_service.dart';
import '../core/theme.dart';
import '../ui/charts.dart';
import '../ui/widgets.dart';

/// Lives outside the page so the timer keeps running while you navigate.
class FocusTimer extends ChangeNotifier {
  FocusTimer._();
  static final FocusTimer instance = FocusTimer._();

  bool running = false;
  DateTime? startedAt;
  DateTime? endAt;
  String subject = 'General';
  int minutes = 25;
  Timer? _t;

  Duration get remaining {
    if (!running) return Duration(minutes: minutes);
    final d = endAt!.difference(DateTime.now());
    return d.isNegative ? Duration.zero : d;
  }

  double get progress {
    if (!running) return 0;
    final total = Duration(minutes: minutes).inSeconds;
    return 1 - remaining.inSeconds / total;
  }

  void start(String s, int m) {
    subject = s.isEmpty ? 'General' : s;
    minutes = m;
    startedAt = DateTime.now();
    endAt = startedAt!.add(Duration(minutes: m));
    running = true;
    NotificationService.instance.scheduleSeries(
      base: 1,
      times: [endAt!],
      title: '⏱ Focus session complete',
      body: '$subject - $m min done. Take a break.',
    );
    _t?.cancel();
    _t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (remaining.inSeconds <= 0) {
        _finish(true);
      } else {
        notifyListeners();
      }
    });
    notifyListeners();
  }

  void stop() => _finish(false);

  void _finish(bool complete) {
    if (!running) return;
    final mins = complete ? minutes : DateTime.now().difference(startedAt!).inMinutes;
    _t?.cancel();
    running = false;
    if (!complete) NotificationService.instance.cancelSeries(1);
    if (mins >= 1) AppState.instance.addSession(subject, mins);
    notifyListeners();
  }
}

class StudyPage extends StatefulWidget {
  const StudyPage({super.key});
  @override
  State<StudyPage> createState() => _StudyPageState();
}

class _StudyPageState extends State<StudyPage> {
  final _subject = TextEditingController(text: FocusTimer.instance.subject);
  int _min = FocusTimer.instance.minutes;

  @override
  void dispose() {
    _subject.dispose();
    super.dispose();
  }

  String _mmss(Duration d) =>
      '${d.inMinutes.toString().padLeft(2, '0')}:${(d.inSeconds % 60).toString().padLeft(2, '0')}';

  @override
  Widget build(BuildContext context) {
    final f = FocusTimer.instance;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: C.bg,
        title: Text('FOCUS TIMER', style: ts(18, m: true, w: FontWeight.w800, ls: 2)),
      ),
      body: ListenableBuilder(
        listenable: Listenable.merge([f, AppState.instance]),
        builder: (context, _) {
          final s = AppState.instance;
          return ListView(padding: const EdgeInsets.all(16), children: [
            Center(
              child: SizedBox(
                width: 220,
                height: 220,
                child: Stack(alignment: Alignment.center, children: [
                  SizedBox(
                    width: 220,
                    height: 220,
                    child: CircularProgressIndicator(
                      value: f.running ? f.progress : 0,
                      strokeWidth: 10,
                      backgroundColor: C.line,
                      color: C.violet,
                    ),
                  ),
                  Column(mainAxisSize: MainAxisSize.min, children: [
                    Text(_mmss(f.remaining), style: ts(46, m: true, w: FontWeight.w800)),
                    Text(f.running ? f.subject.toUpperCase() : 'READY', style: ts(11, m: true, c: C.violet, ls: 2)),
                  ]),
                ]),
              ),
            ),
            const SizedBox(height: 24),
            if (!f.running) ...[
              TextField(controller: _subject, style: ts(15), decoration: deco('Subject', icon: Icons.menu_book)),
              const SizedBox(height: 14),
              ChipRow<int>(
                values: const [15, 25, 45, 60, 90],
                selected: _min,
                color: C.violet,
                label: (v) => '$v min',
                onChanged: (v) => setState(() => _min = v),
              ),
              const SizedBox(height: 18),
              NeonButton('START FOCUS', icon: Icons.play_arrow, color: C.violet, onTap: () => f.start(_subject.text.trim(), _min)),
            ] else
              NeonButton('ABORT & SAVE', icon: Icons.stop, color: C.red, onTap: f.stop),
            const SectionHeader('Minutes studied - 7 days'),
            HudCard(accent: C.violet, child: MiniBar(values: s.studyPerDay(7), labels: s.dayLabels(7), color: C.violet)),
            const SectionHeader('Recent sessions'),
            if (s.sessions.isEmpty)
              const EmptyState(Icons.timer_outlined, 'No sessions yet.')
            else
              for (final x in s.sessions.take(8))
                HudCard(
                  accent: C.violet,
                  margin: const EdgeInsets.only(bottom: 8),
                  padding: const EdgeInsets.all(12),
                  child: Row(children: [
                    const Icon(Icons.check_circle, color: C.violet, size: 20),
                    const SizedBox(width: 10),
                    Expanded(child: Text(x.subject, style: ts(14, w: FontWeight.w700))),
                    Text('${x.minutes} min', style: ts(13, m: true, c: C.violet, w: FontWeight.w800)),
                    const SizedBox(width: 10),
                    Text(fmtDT(x.at), style: ts(10.5, m: true, c: C.dim)),
                  ]),
                ),
          ]);
        },
      ),
    );
  }
}
