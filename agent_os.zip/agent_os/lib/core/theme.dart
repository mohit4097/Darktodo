import 'package:flutter/material.dart';

class C {
  static const bg = Color(0xFF070B10);
  static const surface = Color(0xFF0F151D);
  static const surface2 = Color(0xFF151D28);
  static const line = Color(0xFF1F2A38);
  static const cyan = Color(0xFF00E5FF);
  static const red = Color(0xFFFF3B4E);
  static const green = Color(0xFF39FF9A);
  static const amber = Color(0xFFFFC53D);
  static const violet = Color(0xFFA78BFA);
  static const text = Color(0xFFE6EDF5);
  static const dim = Color(0xFF7E8DA0);
}

const String kMono = 'monospace';

ThemeData buildTheme() {
  final base = ThemeData(brightness: Brightness.dark, useMaterial3: true);
  return base.copyWith(
    scaffoldBackgroundColor: C.bg,
    colorScheme: const ColorScheme.dark(
      primary: C.cyan,
      onPrimary: Colors.black,
      secondary: C.red,
      surface: C.surface,
      onSurface: C.text,
      error: C.red,
    ),
    textTheme: base.textTheme.apply(bodyColor: C.text, displayColor: C.text),
  );
}
