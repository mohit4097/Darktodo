import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'auth.dart';
import 'models.dart';
import 'notification_service.dart';
import 'repository.dart';

class AppState extends ChangeNotifier {
  AppState._();
  static final AppState instance = AppState._();

  late SharedPreferences prefs;
  late AuthService auth;
  late DataRepository repo;

  String space = 'normal';
  bool loaded = false;

  List<Task> tasks = [];
  List<NotifItem> notifs = [];
  List<Habit> habits = [];
  List<StudySession> sessions = [];
  List<Expense> expenses = [];
  List<Exam> exams = [];

  Timer? _ticker;
  final _notif = NotificationService.instance;

  Future<void> init() async {
    prefs = await SharedPreferences.getInstance();
    auth = AuthService(prefs);
    repo = LocalRepository(prefs);
  }

  bool get autoLock => prefs.getBool('auto_lock') ?? true;
  Future<void> setAutoLock(bool v) async {
    await prefs.setBool('auto_lock', v);
    notifyListeners();
  }

  void refreshUi() => notifyListeners();

  int nextId() {
    final v = (prefs.getInt('id_counter') ?? 1000) + 1;
    prefs.setInt('id_counter', v);
    return v;
  }

  // ---------- space lifecycle ----------

  List<T> _list<T>(dynamic v, T Function(Map<String, dynamic>) f) =>
      ((v as List?) ?? []).map((e) => f(Map<String, dynamic>.from(e as Map))).toList();

  Future<void> openSpace(String s) async {
    space = s;
    final m = await repo.load(s) ?? <String, dynamic>{};
    tasks = _list(m['tasks'], Task.fromJson);
    notifs = _list(m['notifs'], NotifItem.fromJson);
    habits = _list(m['habits'], Habit.fromJson);
    sessions = _list(m['sessions'], StudySession.fromJson);
    expenses = _list(m['expenses'], Expense.fromJson);
    exams = _list(m['exams'], Exam.fromJson);
    loaded = true;
    await _sync();
    await _commit(notify: false);
    await rescheduleAll();
    _ticker?.cancel();
    _ticker = Timer.periodic(const Duration(seconds: 20), (_) => refreshHistory());
    notifyListeners();
  }

  void closeSpace() {
    _ticker?.cancel();
    loaded = false;
    tasks = [];
    notifs = [];
    habits = [];
    sessions = [];
    expenses = [];
    exams = [];
    notifyListeners();
  }

  Future<void> _commit({bool notify = true}) async {
    if (!loaded) return;
    await repo.save(space, {
      'tasks': tasks.map((e) => e.toJson()).toList(),
      'notifs': notifs.map((e) => e.toJson()).toList(),
      'habits': habits.map((e) => e.toJson()).toList(),
      'sessions': sessions.map((e) => e.toJson()).toList(),
      'expenses': expenses.map((e) => e.toJson()).toList(),
      'exams': exams.map((e) => e.toJson()).toList(),
    });
    if (notify) notifyListeners();
  }

  // ---------- history sync ----------

  Future<bool> _sync() async {
    final now = DateTime.now();
    var changed = false;
    for (final n in notifs) {
      if (n.status == 'pending' && !n.at.isAfter(now)) {
        n.status = 'delivered';
        changed = true;
      }
    }
    for (final t in tasks) {
      if (t.status != 'active') continue;
      final el = t.elapsed(now);
      if (el.isEmpty) continue;
      for (final at in el) {
        notifs.add(NotifItem(
          id: nextId(),
          title: t.title,
          body: t.note,
          at: at,
          source: 'task',
          status: 'delivered',
        ));
      }
      t.loggedUntil = el.last;
      changed = true;
    }
    if (changed) {
      notifs.sort((a, b) => b.at.compareTo(a.at));
      if (notifs.length > 400) notifs = notifs.sublist(0, 400);
    }
    return changed;
  }

  Future<void> refreshHistory() async {
    if (!loaded) return;
    if (await _sync()) await _commit();
  }

  /// Called when the app comes back to the foreground.
  Future<void> refresh() async {
    if (!loaded) return;
    await _sync();
    await _commit();
    await rescheduleAll();
  }

  // ---------- scheduling ----------

  Future<void> _scheduleTask(Task t, {bool clear = true}) => _notif.scheduleSeries(
        base: t.id,
        times: t.occurrences(),
        title: '⚡ ${t.title}',
        body: t.note.isEmpty ? 'Mission reminder - mark it complete when done.' : t.note,
        clear: clear,
      );

  Future<void> _scheduleNotif(NotifItem n, {bool clear = true}) => _notif.scheduleSeries(
        base: n.id,
        times: [n.at],
        title: '🔔 ${n.title}',
        body: n.body.isEmpty ? 'Scheduled alert' : n.body,
        clear: clear,
      );

  List<DateTime> habitTimes(Habit h, {int days = 30}) {
    if (h.remindMin == null) return [];
    final now = DateTime.now();
    final out = <DateTime>[];
    for (var i = 0; i < days; i++) {
      final d = DateTime(now.year, now.month, now.day + i, h.remindMin! ~/ 60, h.remindMin! % 60);
      if (!d.isAfter(now)) continue;
      if (i == 0 && h.done.contains(dayKey(now))) continue;
      out.add(d);
    }
    return out;
  }

  List<DateTime> examTimes(Exam e) =>
      [e.at.subtract(const Duration(days: 1)), e.at.subtract(const Duration(hours: 1))];

  Future<void> _scheduleHabit(Habit h, {bool clear = true}) => _notif.scheduleSeries(
        base: h.id,
        times: habitTimes(h),
        title: '${h.emoji} ${h.name}',
        body: 'Daily habit check-in. Keep the streak alive.',
        clear: clear,
      );

  Future<void> _scheduleExam(Exam e, {bool clear = true}) => _notif.scheduleSeries(
        base: e.id,
        times: examTimes(e),
        title: '🎓 Exam: ${e.subject}',
        body: 'Exam is coming up on ${DateFormat('d MMM, h:mm a').format(e.at)}. Stay sharp.',
        clear: clear,
      );

  Future<void> rescheduleAll() async {
    await _notif.cancelAll();
    for (final t in tasks.where((t) => t.status == 'active')) {
      await _scheduleTask(t, clear: false);
    }
    for (final n in notifs.where((n) => n.status == 'pending')) {
      await _scheduleNotif(n, clear: false);
    }
    for (final h in habits) {
      await _scheduleHabit(h, clear: false);
    }
    for (final e in exams) {
      await _scheduleExam(e, clear: false);
    }
  }

  // ---------- tasks ----------

  Future<void> addTask({
    required String title,
    String note = '',
    required DateTime due,
    int repeatMin = 0,
    int priority = 1,
  }) async {
    final t = Task(id: nextId(), title: title, note: note, due: due, repeatMin: repeatMin, priority: priority);
    tasks.insert(0, t);
    await _commit();
    await _scheduleTask(t);
  }

  Future<void> completeTask(Task t) async {
    t.status = 'done';
    t.completedAt = DateTime.now();
    await _notif.cancelSeries(t.id);
    await _commit();
  }

  Future<void> deleteTask(Task t) async {
    t.status = 'deleted';
    t.completedAt = DateTime.now();
    await _notif.cancelSeries(t.id);
    await _commit();
  }

  Future<void> purgeTask(Task t) async {
    tasks.remove(t);
    await _commit();
  }

  Future<void> clearTaskHistory() async {
    tasks.removeWhere((t) => t.status != 'active');
    await _commit();
  }

  // ---------- alerts ----------

  Future<void> addNotif(String title, String body, DateTime at) async {
    final n = NotifItem(id: nextId(), title: title, body: body, at: at);
    notifs.insert(0, n);
    await _commit();
    await _scheduleNotif(n);
  }

  Future<void> cancelNotif(int id) async {
    for (final n in notifs) {
      if (n.id == id) n.status = 'cancelled';
    }
    await _notif.cancelSeries(id);
    await _commit();
  }

  Future<void> removeNotif(NotifItem n) async {
    notifs.remove(n);
    await _commit();
  }

  Future<void> clearNotifHistory() async {
    notifs.removeWhere((n) => n.status != 'pending');
    await _commit();
  }

  List<Upcoming> upcoming() {
    final now = DateTime.now();
    final out = <Upcoming>[];
    for (final n in notifs) {
      if (n.status == 'pending' && n.at.isAfter(now)) out.add(Upcoming(n.title, 'custom', n.at, n.id));
    }
    for (final t in tasks.where((t) => t.status == 'active')) {
      final o = t.occurrences(max: 1);
      if (o.isNotEmpty) out.add(Upcoming(t.title, 'task', o.first));
    }
    for (final h in habits) {
      final o = habitTimes(h, days: 2);
      if (o.isNotEmpty) out.add(Upcoming('${h.emoji} ${h.name}', 'habit', o.first));
    }
    for (final e in exams) {
      for (final tm in examTimes(e)) {
        if (tm.isAfter(now)) {
          out.add(Upcoming('Exam: ${e.subject}', 'exam', tm));
          break;
        }
      }
    }
    out.sort((a, b) => a.at.compareTo(b.at));
    return out;
  }

  // ---------- habits ----------

  Future<void> addHabit(String name, String emoji, int? remindMin) async {
    final h = Habit(id: nextId(), name: name, emoji: emoji, remindMin: remindMin);
    habits.add(h);
    await _commit();
    await _scheduleHabit(h);
  }

  Future<void> toggleHabit(Habit h, DateTime day) async {
    final k = dayKey(day);
    if (!h.done.remove(k)) h.done.add(k);
    await _commit();
    await _scheduleHabit(h);
  }

  Future<void> deleteHabit(Habit h) async {
    habits.remove(h);
    await _notif.cancelSeries(h.id);
    await _commit();
  }

  // ---------- study ----------

  Future<void> addSession(String subject, int minutes) async {
    sessions.insert(0, StudySession(subject: subject, minutes: minutes, at: DateTime.now()));
    await _commit();
  }

  // ---------- expenses ----------

  Future<void> addExpense(double amount, String category, String note) async {
    expenses.insert(0, Expense(id: nextId(), amount: amount, category: category, note: note, at: DateTime.now()));
    await _commit();
  }

  Future<void> deleteExpense(Expense e) async {
    expenses.remove(e);
    await _commit();
  }

  // ---------- exams ----------

  Future<void> addExam(String subject, DateTime at) async {
    final e = Exam(id: nextId(), subject: subject, at: at);
    exams.add(e);
    exams.sort((a, b) => a.at.compareTo(b.at));
    await _commit();
    await _scheduleExam(e);
  }

  Future<void> deleteExam(Exam e) async {
    exams.remove(e);
    await _notif.cancelSeries(e.id);
    await _commit();
  }

  // ---------- stats for charts ----------

  DateTime _day(int back) {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day - back);
  }

  List<String> dayLabels(int n) =>
      List.generate(n, (i) => DateFormat('E').format(_day(n - 1 - i)).substring(0, 1));

  List<double> completedPerDay(int n) => List.generate(n, (i) {
        final k = dayKey(_day(n - 1 - i));
        return tasks
            .where((t) => t.status == 'done' && t.completedAt != null && dayKey(t.completedAt!) == k)
            .length
            .toDouble();
      });

  List<double> studyPerDay(int n) => List.generate(n, (i) {
        final k = dayKey(_day(n - 1 - i));
        return sessions.where((s) => dayKey(s.at) == k).fold<int>(0, (a, s) => a + s.minutes).toDouble();
      });

  int get studyToday => studyPerDay(1).first.toInt();
  int get doneToday => completedPerDay(1).first.toInt();
  int get pendingCount => tasks.where((t) => t.status == 'active').length;
  int get bestStreak => habits.fold<int>(0, (a, h) => h.streak > a ? h.streak : a);
  int get habitsDoneToday => habits.where((h) => h.done.contains(dayKey(DateTime.now()))).length;

  double get monthSpend {
    final n = DateTime.now();
    return expenses.where((e) => e.at.year == n.year && e.at.month == n.month).fold<double>(0, (a, e) => a + e.amount);
  }

  Map<String, double> get monthByCategory {
    final n = DateTime.now();
    final m = <String, double>{};
    for (final e in expenses.where((e) => e.at.year == n.year && e.at.month == n.month)) {
      m[e.category] = (m[e.category] ?? 0) + e.amount;
    }
    return m;
  }
}
