import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;
import 'models.dart';

/// Schedules local notifications. Each item owns a "series" of ids:
/// id = base * 64 + index, so a repeating reminder is just many one-off alarms
/// that get refreshed every time the app opens.
class NotificationService {
  NotificationService._();
  static final NotificationService instance = NotificationService._();

  final FlutterLocalNotificationsPlugin _plugin = FlutterLocalNotificationsPlugin();
  static const int _slots = 64;

  Future<void> init() async {
    tzdata.initializeTimeZones();
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    await _plugin.initialize(const InitializationSettings(android: android));
  }

  AndroidFlutterLocalNotificationsPlugin? get _android =>
      _plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  Future<bool> requestPermission() async {
    try {
      return (await _android?.requestNotificationsPermission()) ?? false;
    } catch (_) {
      return false;
    }
  }

  Future<void> requestExactAlarms() async {
    try {
      await _android?.requestExactAlarmsPermission();
    } catch (_) {}
  }

  Future<AndroidScheduleMode> _mode() async {
    try {
      final can = await _android?.canScheduleExactNotifications();
      if (can == true) return AndroidScheduleMode.exactAllowWhileIdle;
    } catch (_) {}
    return AndroidScheduleMode.inexactAllowWhileIdle;
  }

  NotificationDetails _details(String body) => NotificationDetails(
        android: AndroidNotificationDetails(
          'agent_alerts',
          'Mission Alerts',
          channelDescription: 'Reminders and alerts from AGENT.OS',
          importance: Importance.max,
          priority: Priority.high,
          styleInformation: BigTextStyleInformation(body),
        ),
      );

  Future<void> showNow(String title, String body) async {
    try {
      await _plugin.show(0, title, body, _details(body));
    } catch (_) {}
  }

  Future<void> scheduleSeries({
    required int base,
    required List<DateTime> times,
    required String title,
    required String body,
    bool clear = true,
  }) async {
    if (clear) await cancelSeries(base);
    final mode = await _mode();
    final now = DateTime.now();
    for (var i = 0; i < times.length && i < kMaxSeries; i++) {
      if (!times[i].isAfter(now)) continue;
      try {
        await _plugin.zonedSchedule(
          base * _slots + i,
          title,
          body,
          tz.TZDateTime.from(times[i], tz.UTC),
          _details(body),
          androidScheduleMode: mode,
          uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
        );
      } catch (_) {}
    }
  }

  Future<void> cancelSeries(int base) async {
    try {
      final pending = await _plugin.pendingNotificationRequests();
      for (final p in pending) {
        if (p.id ~/ _slots == base) await _plugin.cancel(p.id);
      }
    } catch (_) {}
  }

  Future<void> cancelAll() async {
    try {
      await _plugin.cancelAll();
    } catch (_) {}
  }
}
