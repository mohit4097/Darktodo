DateTime? _dt(dynamic v) => v == null ? null : DateTime.fromMillisecondsSinceEpoch(v as int);
int? _ms(DateTime? d) => d?.millisecondsSinceEpoch;

String dayKey(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';
DateTime dayStart(DateTime d) => DateTime(d.year, d.month, d.day);
DateTime plusDays(DateTime d, int n) => DateTime(d.year, d.month, d.day + n);

/// Max notifications scheduled per series (id = base * 64 + index).
const int kMaxSeries = 60;

class Task {
  int id;
  String title;
  String note;
  DateTime due;
  int repeatMin; // 0 = once
  int priority; // 0 low, 1 medium, 2 high
  String status; // active | done | deleted
  DateTime created;
  DateTime? completedAt;
  DateTime? loggedUntil;

  Task({
    required this.id,
    required this.title,
    this.note = '',
    required this.due,
    this.repeatMin = 0,
    this.priority = 1,
    this.status = 'active',
    DateTime? created,
    this.completedAt,
    this.loggedUntil,
  }) : created = created ?? DateTime.now();

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'note': note,
        'due': _ms(due),
        'repeatMin': repeatMin,
        'priority': priority,
        'status': status,
        'created': _ms(created),
        'completedAt': _ms(completedAt),
        'loggedUntil': _ms(loggedUntil),
      };

  factory Task.fromJson(Map<String, dynamic> j) => Task(
        id: j['id'] as int,
        title: j['title'] as String,
        note: (j['note'] as String?) ?? '',
        due: _dt(j['due'])!,
        repeatMin: (j['repeatMin'] as int?) ?? 0,
        priority: (j['priority'] as int?) ?? 1,
        status: (j['status'] as String?) ?? 'active',
        created: _dt(j['created']),
        completedAt: _dt(j['completedAt']),
        loggedUntil: _dt(j['loggedUntil']),
      );

  /// Future reminder times (from [from], default now).
  List<DateTime> occurrences({DateTime? from, int max = kMaxSeries}) {
    final f = from ?? DateTime.now();
    final out = <DateTime>[];
    if (repeatMin <= 0) {
      if (due.isAfter(f)) out.add(due);
      return out;
    }
    var t = due;
    if (t.isBefore(f)) {
      final diff = f.difference(t).inMinutes;
      final k = (diff / repeatMin).ceil();
      t = due.add(Duration(minutes: k * repeatMin));
    }
    while (out.length < max) {
      out.add(t);
      t = t.add(Duration(minutes: repeatMin));
    }
    return out;
  }

  /// Reminder times that already passed and were not logged yet.
  List<DateTime> elapsed(DateTime now) {
    if (due.isAfter(now)) return [];
    if (repeatMin <= 0) return loggedUntil == null ? [due] : [];
    var k = 0;
    if (loggedUntil != null) {
      k = loggedUntil!.difference(due).inMinutes ~/ repeatMin + 1;
    }
    final out = <DateTime>[];
    var t = due.add(Duration(minutes: k * repeatMin));
    while (!t.isAfter(now) && out.length < 500) {
      out.add(t);
      t = t.add(Duration(minutes: repeatMin));
    }
    return out.length > 8 ? out.sublist(out.length - 8) : out;
  }
}

class NotifItem {
  int id;
  String title;
  String body;
  DateTime at;
  String source; // custom | task
  String status; // pending | delivered | cancelled

  NotifItem({
    required this.id,
    required this.title,
    this.body = '',
    required this.at,
    this.source = 'custom',
    this.status = 'pending',
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'at': _ms(at),
        'source': source,
        'status': status,
      };

  factory NotifItem.fromJson(Map<String, dynamic> j) => NotifItem(
        id: j['id'] as int,
        title: j['title'] as String,
        body: (j['body'] as String?) ?? '',
        at: _dt(j['at'])!,
        source: (j['source'] as String?) ?? 'custom',
        status: (j['status'] as String?) ?? 'pending',
      );
}

class Habit {
  int id;
  String name;
  String emoji;
  Set<String> done;
  int? remindMin; // minutes since midnight

  Habit({
    required this.id,
    required this.name,
    this.emoji = '🎯',
    Set<String>? done,
    this.remindMin,
  }) : done = done ?? <String>{};

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'emoji': emoji,
        'done': done.toList(),
        'remindMin': remindMin,
      };

  factory Habit.fromJson(Map<String, dynamic> j) => Habit(
        id: j['id'] as int,
        name: j['name'] as String,
        emoji: (j['emoji'] as String?) ?? '🎯',
        done: ((j['done'] as List?) ?? []).map((e) => e as String).toSet(),
        remindMin: j['remindMin'] as int?,
      );

  int get streak {
    var d = DateTime.now();
    if (!done.contains(dayKey(d))) d = plusDays(d, -1);
    var n = 0;
    while (done.contains(dayKey(d))) {
      n++;
      d = plusDays(d, -1);
    }
    return n;
  }
}

class StudySession {
  String subject;
  int minutes;
  DateTime at;
  StudySession({required this.subject, required this.minutes, required this.at});

  Map<String, dynamic> toJson() => {'subject': subject, 'minutes': minutes, 'at': _ms(at)};
  factory StudySession.fromJson(Map<String, dynamic> j) => StudySession(
        subject: j['subject'] as String,
        minutes: j['minutes'] as int,
        at: _dt(j['at'])!,
      );
}

class Expense {
  int id;
  double amount;
  String category;
  String note;
  DateTime at;
  Expense({required this.id, required this.amount, required this.category, this.note = '', required this.at});

  Map<String, dynamic> toJson() =>
      {'id': id, 'amount': amount, 'category': category, 'note': note, 'at': _ms(at)};
  factory Expense.fromJson(Map<String, dynamic> j) => Expense(
        id: j['id'] as int,
        amount: (j['amount'] as num).toDouble(),
        category: j['category'] as String,
        note: (j['note'] as String?) ?? '',
        at: _dt(j['at'])!,
      );
}

class Exam {
  int id;
  String subject;
  DateTime at;
  Exam({required this.id, required this.subject, required this.at});

  Map<String, dynamic> toJson() => {'id': id, 'subject': subject, 'at': _ms(at)};
  factory Exam.fromJson(Map<String, dynamic> j) =>
      Exam(id: j['id'] as int, subject: j['subject'] as String, at: _dt(j['at'])!);
}

class Upcoming {
  final String title;
  final String source; // custom | task | habit | exam
  final DateTime at;
  final int? notifId;
  Upcoming(this.title, this.source, this.at, [this.notifId]);
}
