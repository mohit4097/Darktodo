import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Storage abstraction. Each "space" ('normal', later 'secret') is stored separately.
///
/// Today: [LocalRepository] (on-device storage).
/// Later: add a `FirebaseRepository implements DataRepository` that reads/writes
/// Firestore / Storage under users/{uid}/spaces/{space}. Nothing else in the app
/// needs to change - AppState only talks to this interface.
abstract class DataRepository {
  Future<Map<String, dynamic>?> load(String space);
  Future<void> save(String space, Map<String, dynamic> data);
}

class LocalRepository implements DataRepository {
  final SharedPreferences prefs;
  LocalRepository(this.prefs);

  @override
  Future<Map<String, dynamic>?> load(String space) async {
    final raw = prefs.getString('data_$space');
    if (raw == null) return null;
    try {
      return Map<String, dynamic>.from(jsonDecode(raw) as Map);
    } catch (_) {
      return null;
    }
  }

  @override
  Future<void> save(String space, Map<String, dynamic> data) async {
    await prefs.setString('data_$space', jsonEncode(data));
  }
}
