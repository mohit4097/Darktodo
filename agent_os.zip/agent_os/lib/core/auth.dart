import 'dart:convert';
import 'dart:math';
import 'package:crypto/crypto.dart';
import 'package:shared_preferences/shared_preferences.dart';

enum AuthResult { normal, secret, denied }

/// One password box on the lock screen. The entered password decides the space:
///  - matches the normal password  -> normal space
///  - matches the (future) secret password -> secret space
/// The UI never says which is which.
class AuthService {
  final SharedPreferences prefs;
  AuthService(this.prefs);

  static const _kNormal = 'auth_normal';
  static const _kSecret = 'auth_secret';
  static const _kSalt = 'auth_salt';

  bool get hasNormal => prefs.getString(_kNormal) != null;
  bool get hasSecret => prefs.getString(_kSecret) != null;
  bool get hasLock => hasNormal;

  String _salt() {
    var s = prefs.getString(_kSalt);
    if (s == null) {
      final r = Random.secure();
      s = base64UrlEncode(List<int>.generate(16, (_) => r.nextInt(256)));
      prefs.setString(_kSalt, s);
    }
    return s;
  }

  String _hash(String pwd) => sha256.convert(utf8.encode('${_salt()}::$pwd')).toString();

  Future<void> setNormal(String pwd) async => prefs.setString(_kNormal, _hash(pwd));
  Future<void> removeNormal() async => prefs.remove(_kNormal);

  /// Ready for the secret system (not exposed in the UI yet).
  Future<bool> setSecret(String pwd) async {
    if (hasNormal && prefs.getString(_kNormal) == _hash(pwd)) return false;
    await prefs.setString(_kSecret, _hash(pwd));
    return true;
  }

  AuthResult verify(String pwd) {
    final h = _hash(pwd);
    if (hasSecret && prefs.getString(_kSecret) == h) return AuthResult.secret;
    if (hasNormal && prefs.getString(_kNormal) == h) return AuthResult.normal;
    return AuthResult.denied;
  }

  bool verifyNormal(String pwd) => hasNormal && prefs.getString(_kNormal) == _hash(pwd);
}
