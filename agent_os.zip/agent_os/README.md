# AGENT.OS

Dark "mission control" productivity app (Flutter, Android).

## Features (Normal mode)
- Password lock (optional, like Telegram) - one password box, no hints
- Missions (tasks) with date/time + repeat reminders: every 30 min / 1 / 2 / 6 hr / daily, repeating until you mark them complete
- Alerts: scheduled notifications + Notification History tab
- Mission History tab (completed + deleted tasks)
- Dashboard with charts (missions, study minutes, habits ring, next exam)
- Lab: Habits (streaks), Focus Timer, Exams countdown, Expenses (donut chart), GPA calculator
- Everything saved on the phone (local storage)

## Build the APK on GitHub
1. Create a new GitHub repo and upload ALL files of this folder (keep the `.github` folder!).
2. Go to the **Actions** tab -> "Build APK" -> run it (it also runs on every push).
3. When finished, open the run -> **Artifacts** -> download `agent-os-apk` -> unzip -> install `app-release.apk`.

The workflow generates the Android project itself and patches permissions (`tool/setup_android.py`),
so there is no `android/` folder in the repo.

## Ready for the secret system (after exams)
- `core/auth.dart`: one password box -> `AuthResult.normal` or `AuthResult.secret` (secret hash support already exists)
- `core/repository.dart`: `DataRepository` interface; each space ('normal', 'secret') is stored separately.
  Add a `FirebaseRepository` here to move storage to Firebase without touching the UI.
- `pages/root_gate.dart` routes to `Shell` (normal) or `SecretHome` (placeholder).
